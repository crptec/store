<?php
/* 
 * Copyright (C) 2022		CRPTEC      <crptec.fr@gmail.com>
 *
 */

require '../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/commande/class/commande.class.php';
require_once DOL_DOCUMENT_ROOT.'/commande/class/commandestats.class.php';

$userid = GETPOST('userid', 'int');
$socid = GETPOST('socid', 'int');
// Security check
if ($user->socid > 0) {
	$action = '';
	$socid = $user->socid;
}

$mode = GETPOSTISSET("mode") ? GETPOST("mode", 'aZ09') : 'customer';
if ($mode == 'customer' && !$user->rights->commande->lire) {
	accessforbidden();
}
if ($mode == 'supplier' && empty($user->rights->fournisseur->commande->lire)) {
	accessforbidden();
}
if ($mode == 'supplier') {
	$object_status = GETPOST('object_status', 'array:int');
	$object_status = implode(',', $object_status);
} else {
	$object_status = GETPOST('object_status', 'intcomma');
}

$typent_id = GETPOST('typent_id', 'int');
$categ_id = GETPOST('categ_id', 'categ_id');

// Load translation files required by the page
$langs->loadLangs(array('orders', 'other', 'companies', 'exports'));

// Security check
if ($user->socid) {
	$socid = $user->socid;
}

$nowyear = dol_print_date(dol_now(), "%Y");
$nowmonth = dol_print_date(dol_now(), "%m");
$year = GETPOST('year') > 0 ?GETPOST('year') : $nowyear;
$month = GETPOST('month') > 0 ?GETPOST('month') : $nowmonth;

$stats = new CommandeStats($db, $socid, $mode, ($userid > 0 ? $userid : 0), ($typent_id > 0 ? $typent_id : 0), ($categ_id > 0 ? $categ_id : 0));

$stockout = $stats->getCommandsByMonth($year, $month);

$generic_commande = new Commande($db);
/*CSV file*/
$filename = 'OrderList.csv';
$dirname = DOL_DATA_ROOT.'/stock';
$array_fields = array('id', 'ref', 'date', 'client', 'HT', 'TVA', 'TTC','status', 'alarm');
// Open file
dol_mkdir($dirname);
$filePath=$dirname."/".$filename;
$handle = fopen($filePath, "wt");
if (!$handle) {
	$langs->load("errors");
	$error = $langs->trans("ErrorFailToCreateFile", $filePath);
	error_log("ERROR: ".$error);
} else {
	// Genere en-tete
	foreach ($array_fields as $val) {
		$newvalue = $langs->transnoentities($val);
		fwrite($handle, $newvalue.";");
	}
	fwrite($handle, "\n");
	// Generate value
	foreach ($stockout as $val) {
		$status_text = $generic_commande->LibStatut($val[12], $val[13], 5, 1);

		$text = $val[0].';'.$val[1].';'.$val[2].';'.$val[3].';'.price(price2num($val[4], 'MT'), 1).';'.price(price2num($val[5], 'MT'), 1).';'.price(price2num($val[6], 'MT'), 1).';'.$langs->trans($status_text).';0';
		fwrite($handle, $text."\n");
	}
	// Close file
	fclose($handle);

	// Output to http stream
	dol_sanitizeFileName($filePath);
	clearstatcache();
	$attachment = true;
	$type = dol_mimetype($filename);
	header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
	if ($type) {
		header('Content-Type: '.$type);
	}

	if ($type) {
		header('Content-Type: '.$type);
	}
	if ($attachment) {
		header('Content-Disposition: attachment; filename="'.$filename.'"');
	} else {
		header('Content-Disposition: inline; filename="'.$filename.'"');
	}
	header('Cache-Control: Public, must-revalidate');
	header('Pragma: public');
	flush();
	readfile($filePath);

	clearstatcache();
	$backurl = dol_buildpath('/commande/stats/index.php?', 1);
	header("Location: ".$backurl);
	exit;
}


?>