<?php
/* 
 * Copyright (C) 2022		CRPTEC      <crptec.fr@gmail.com>
 *
 */

require '../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/expedition/class/expedition.class.php';
require_once DOL_DOCUMENT_ROOT.'/expedition/class/expeditionstats.class.php';

$userid = GETPOST('userid', 'int');
$socid = GETPOST('socid', 'int');
// Security check
if ($user->socid > 0) {
	$action = '';
	$socid = $user->socid;
}

// Load translation files required by the page
$langs->loadLangs(array('sendings', 'other', 'companies', 'exports'));

// Security check
if ($user->socid) {
	$socid = $user->socid;
}
restrictedArea($user, 'expedition');

$nowyear = dol_print_date(dol_now(), "%Y");
$nowmonth = dol_print_date(dol_now(), "%m");
$year = GETPOST('year') > 0 ?GETPOST('year') : $nowyear;
$month = GETPOST('month') > 0 ?GETPOST('month') : $nowmonth;

$stats = new ExpeditionStats($db, $socid, '', ($userid > 0 ? $userid : 0));

$stockout = $stats->getProductsByMonth($year, $month);

/*CSV file*/
$filename = 'stockout.csv';
$dirname = DOL_DATA_ROOT.'/stock';
$array_fields = array('id', 'ref', 'label', 'packQty', 'ordered(u.)', 'ordered(c.)','shipped(u.)', 'shipped(c.)', 'alarm');
// Open file
dol_mkdir($dirname);
$filePath=$dirname."/".$filename;
$handle = fopen($filePath, "wt");
if (!$handle) {
	$langs->load("errors");
	$error = $langs->trans("ErrorFailToCreateFile", $filePath);
	error_log("ERROR: ".$error);
} else {
	// Genere en-tete
	foreach ($array_fields as $val) {
		$newvalue = $langs->transnoentities($val);
		fwrite($handle, $newvalue.";");
	}
	fwrite($handle, "\n");
	// Generate value
	foreach ($stockout as $val) {
		$asked_u = ($val[4] % $val[3]);
		$asked_c = intdiv($val[4],$val[3]);
		$shipped_u = ($val[5] % $val[3]);
		$shipped_c = intdiv($val[5],$val[3]);
		$alarm = (abs($asked_u - $shipped_u) > 0 || abs($asked_c - $shipped_c) > 0) ? 1 : 0;
		$text = $val[0].';'.$val[1].';'.$val[2].';'.$val[3].';'.$asked_u.';'.$asked_c.';'.$shipped_u.';'.$shipped_c.';'.$alarm;
		fwrite($handle, $text."\n");
	}
	// Close file
	fclose($handle);

	// Output to http stream
	dol_sanitizeFileName($filePath);
	clearstatcache();
	$attachment = true;
	$type = dol_mimetype($filename);
	header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
	if ($type) {
		header('Content-Type: '.$type);
	}

	if ($type) {
		header('Content-Type: '.$type);
	}
	if ($attachment) {
		header('Content-Disposition: attachment; filename="'.$filename.'"');
	} else {
		header('Content-Disposition: inline; filename="'.$filename.'"');
	}
	header('Cache-Control: Public, must-revalidate');
	header('Pragma: public');
	flush();
	readfile($filePath);

	clearstatcache();
	$backurl = dol_buildpath('/expedition/stats/index.php?', 1);
	header("Location: ".$backurl);
	exit;
}


?>