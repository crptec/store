<?php
/* 
 * Copyright (C) 2022		CRPTEC      <crptec.fr@gmail.com>
 *
 */

require '../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/product/stock/class/entrepot.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formother.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.form.class.php';
require_once DOL_DOCUMENT_ROOT.'/fourn/class/fournisseur.commande.class.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/html.formproduct.class.php';
require_once './lib/replenishment.lib.php';

// Load translation files required by the page
$langs->loadLangs(array('products', 'stocks', 'orders'));

// Security check
if ($user->socid) {
	$socid = $user->socid;
}
$result = restrictedArea($user, 'produit|service');

//checks if a product has been ordered

$action = GETPOST('action', 'aZ09');
$type = GETPOST('type', 'int');
$mode = GETPOST('mode', 'alpha');

$date = '';
$dateendofday = '';
if (GETPOSTISSET('dateday') && GETPOSTISSET('datemonth') && GETPOSTISSET('dateyear')) {
	$date = dol_mktime(0, 0, 0, GETPOST('datemonth', 'int'), GETPOST('dateday', 'int'), GETPOST('dateyear', 'int'));
	$dateendofday = dol_mktime(23, 59, 59, GETPOST('datemonth', 'int'), GETPOST('dateday', 'int'), GETPOST('dateyear', 'int'));
}

$now = dol_now();

$dateIsValid = true;
if ($date && $date > $now) {
	setEventMessages($langs->trans("ErrorDateMustBeBeforeToday"), null, 'errors');
	$dateIsValid = false;
}

$productid = GETPOST('productid', 'int');
$fk_warehouse = GETPOST('fk_warehouse', 'int');

$warehouseStatus = array();
if (!empty($conf->global->ENTREPOT_EXTRA_STATUS)) {
	//$warehouseStatus[] = Entrepot::STATUS_CLOSED;
	$warehouseStatus[] = Entrepot::STATUS_OPEN_ALL;
	$warehouseStatus[] = Entrepot::STATUS_OPEN_INTERNAL;
}

$num = 0;

// Get array with current stock per product, warehouse
$stock_prod_warehouse = array();
$stock_prod = array();
if ($date && $dateIsValid) {	// Avoid heavy sql if mandatory date is not defined
	$sql = "SELECT ps.fk_product, ps.fk_entrepot as fk_warehouse,";
	$sql .= " SUM(ps.reel) AS stock";
	$sql .= " FROM ".MAIN_DB_PREFIX."product_stock as ps";
	$sql .= ", ".MAIN_DB_PREFIX."entrepot as w";
	$sql .= " WHERE w.entity IN (".getEntity('stock').")";
	$sql .= " AND w.rowid = ps.fk_entrepot";
	if (!empty($conf->global->ENTREPOT_EXTRA_STATUS) && count($warehouseStatus)) {
		$sql .= " AND w.statut IN (".$db->sanitize(implode(',', $warehouseStatus)).")";
	}
	if ($productid > 0) {
		$sql .= " AND ps.fk_product = ".((int) $productid);
	}
	if ($fk_warehouse > 0) {
		$sql .= " AND ps.fk_entrepot = ".((int) $fk_warehouse);
	}
	$sql .= " GROUP BY fk_product, fk_entrepot";
	//print $sql;

	$resql = $db->query($sql);
	if ($resql) {
		$num = $db->num_rows($resql);
		$i = 0;

		while ($i < $num) {
			$obj = $db->fetch_object($resql);

			$tmp_fk_product   = $obj->fk_product;
			$tmp_fk_warehouse = $obj->fk_warehouse;
			$stock = $obj->stock;

			$stock_prod_warehouse[$tmp_fk_product][$tmp_fk_warehouse] = $stock;
			$stock_prod[$tmp_fk_product] = (isset($stock_prod[$tmp_fk_product]) ? $stock_prod[$tmp_fk_product] : 0) + $stock;

			$i++;
		}

		$db->free($resql);
	} else {
		dol_print_error($db);
	}
	//var_dump($stock_prod_warehouse);
} elseif ($action == 'filter') {
	setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv("Date")), null, 'errors');
}

// Get array with list of stock movements between date and now for product/warehouse=
$movements_prod_warehouse = array();
$movements_prod = array();
$movements_prod_warehouse_nb = array();
$movements_prod_nb = array();
if ($date && $dateIsValid) {
	$sql = "SELECT sm.fk_product, sm.fk_entrepot, SUM(sm.value) AS stock, COUNT(sm.rowid) AS nbofmovement";
	$sql .= " FROM ".MAIN_DB_PREFIX."stock_mouvement as sm";
	$sql .= ", ".MAIN_DB_PREFIX."entrepot as w";
	$sql .= " WHERE w.entity IN (".getEntity('stock').")";
	$sql .= " AND w.rowid = sm.fk_entrepot";
	if (!empty($conf->global->ENTREPOT_EXTRA_STATUS) && count($warehouseStatus)) {
		$sql .= " AND w.statut IN (".$db->sanitize(implode(',', $warehouseStatus)).")";
	}
	if ($mode == 'future') {
		$sql .= " AND sm.datem <= '".$db->idate($dateendofday)."'";
	} else {
		$sql .= " AND sm.datem >= '".$db->idate($dateendofday)."'";
	}
	if ($productid > 0) {
		$sql .= " AND sm.fk_product = ".((int) $productid);
	}
	if ($fk_warehouse > 0) {
		$sql .= " AND sm.fk_entrepot = ".((int) $fk_warehouse);
	}
	$sql .= " GROUP BY sm.fk_product, sm.fk_entrepot";
	$resql = $db->query($sql);

	if ($resql) {
		$num = $db->num_rows($resql);
		$i = 0;

		while ($i < $num) {
			$obj = $db->fetch_object($resql);
			$fk_product = $obj->fk_product;
			$fk_entrepot 	= $obj->fk_entrepot;
			$stock = $obj->stock;
			$nbofmovement	= $obj->nbofmovement;

			// Pour llx_product_stock.reel
			$movements_prod_warehouse[$fk_product][$fk_entrepot] = $stock;
			$movements_prod_warehouse_nb[$fk_product][$fk_entrepot] = $nbofmovement;

			// Pour llx_product.stock
			$movements_prod[$fk_product] += $stock;
			$movements_prod_nb[$fk_product] += $nbofmovement;

			$i++;
		}

		$db->free($resql);
	} else {
		dol_print_error($db);
	}
}

$title = $langs->trans('StockAtDate');
$prod = new Product($db);

$sql = 'SELECT p.rowid, p.ref, p.label, p.description, p.price,';
$sql .= ' p.price_ttc, p.price_base_type, p.fk_product_type, p.desiredstock, p.seuil_stock_alerte,';
$sql .= ' p.tms as datem, p.duration, p.tobuy, p.stock, ';
if (empty($conf->global->EXPEDITION_STATS_KIT_CARTON)) {
	$sql .= " 0 as qty_fils,";
} else {
	$sql .= " pas.qty as qty_fils, ";
}
if ($fk_warehouse > 0) {
	$sql .= " SUM(p.pmp * ps.reel) as estimatedvalue, SUM(p.price * ps.reel) as sellvalue";
	$sql .= ', SUM(ps.reel) as stock_reel';
} else {
	$sql .= " SUM(p.pmp * p.stock) as estimatedvalue, SUM(p.price * p.stock) as sellvalue";
}

$sql .= ' FROM '.MAIN_DB_PREFIX.'product as p';
if (empty($conf->global->EXPEDITION_STATS_KIT_CARTON)) {
	//do nothing
} else {
	//get carton qty in product_association
	$sql .= " LEFT JOIN ".MAIN_DB_PREFIX."product_association as pas ON p.rowid = pas.fk_product_fils";
}
if ($fk_warehouse > 0) {
	$sql .= ' LEFT JOIN '.MAIN_DB_PREFIX.'product_stock as ps ON p.rowid = ps.fk_product AND ps.fk_entrepot = '.((int) $fk_warehouse);
}

$sql .= ' WHERE p.entity IN ('.getEntity('product').')';
if ($productid > 0) {
	$sql .= " AND p.rowid = ".((int) $productid);
}
if (empty($conf->global->STOCK_SUPPORTS_SERVICES)) {
	$sql .= " AND p.fk_product_type = 0";
}
if (!empty($canvas)) {
	$sql .= " AND p.canvas = '".$db->escape($canvas)."'";
}
if ($fk_warehouse > 0) {
	$sql .= ' GROUP BY p.rowid, p.ref, p.label, p.description, p.price, p.price_ttc, p.price_base_type, p.fk_product_type, p.desiredstock, p.seuil_stock_alerte,';
	$sql .= ' p.tms, p.duration, p.tobuy, p.stock';
} else {
	$sql .= ' GROUP BY p.rowid, p.ref, p.label, p.description, p.price, p.price_ttc, p.price_base_type, p.fk_product_type, p.desiredstock, p.seuil_stock_alerte,';
	$sql .= ' p.tms, p.duration, p.tobuy, p.stock';
}
if (empty($conf->global->EXPEDITION_STATS_KIT_CARTON)) {
	$sql .= "";
} else {
	$sql .= ", pas.qty ";
}
if ($sortfield == 'stock_reel' && $fk_warehouse <= 0) {
	$sortfield = 'stock';
}
if ($sortfield == 'stock' && $fk_warehouse > 0) {
	$sortfield = 'stock_reel';
}
$sql .= $db->order($sortfield, $sortorder);

$nbtotalofrecords = 0;
if ($date && $dateIsValid) {	// We avoid a heavy sql if mandatory parameter date not yet defined
	//print $sql;
	$resql = $db->query($sql);
	if (empty($resql)) {
		dol_print_error($db);
		exit;
	}

	$num = $db->num_rows($resql);
}

/*CSV file*/
$filename = 'stockatdate.csv';
$dirname = DOL_DATA_ROOT.'/stock';
$array_fields = array('Ref', 'Label', 'StockAtHistoricalDate', 'CurrentStock(Car.)', 'CurrentStock(u.)');
// Open file
dol_mkdir($dirname);
$filePath=$dirname."/".$filename;
$handle = fopen($filePath, "wt");
if (!$handle) {
	$langs->load("errors");
	$error = $langs->trans("ErrorFailToCreateFile", $filePath);
	error_log("ERROR: ".$error);
} else {
	// Genere en-tete
	foreach ($array_fields as $val) {
		$newvalue = $langs->transnoentities($val);
		fwrite($handle, $newvalue.";");
	}
	fwrite($handle, "\n");
	// Generate value
	$i = 0;
	while ($i < $num) {
		$objp = $db->fetch_object($resql);
		if (!empty($conf->global->STOCK_SUPPORTS_SERVICES) || $objp->fk_product_type == 0) {
			$prod->fetch($objp->rowid);
			$currentstock = '';
			if ($fk_warehouse > 0) {
				$currentstock = $stock_prod_warehouse[$objp->rowid][$fk_warehouse];
			} else {
				$currentstock = $stock_prod[$objp->rowid];
			}

			if ($fk_warehouse > 0) {
				$stock = $currentstock - $movements_prod_warehouse[$objp->rowid][$fk_warehouse];
			} else {
				$stock = $currentstock - $movements_prod[$objp->rowid];
			}
			$text = $prod->ref.';'.$objp->label.';'.$stock.';'.$currentstock.';'.$objp->qty_fils;
			fwrite($handle, $text."\n");
		}
		$i++;
	}
	// Close file
	fclose($handle);

	// Output to http stream
	dol_sanitizeFileName($filePath);
	clearstatcache();
	$attachment = true;
	$type = dol_mimetype($filename);
	header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
	if ($type) {
		header('Content-Type: '.$type);
	}

	if ($type) {
		header('Content-Type: '.$type);
	}
	if ($attachment) {
		header('Content-Disposition: attachment; filename="'.$filename.'"');
	} else {
		header('Content-Disposition: inline; filename="'.$filename.'"');
	}
	header('Cache-Control: Public, must-revalidate');
	header('Pragma: public');
	flush();
	readfile($filePath);

	clearstatcache();
	$backurl = dol_buildpath('/product/stock/stockatdate.php?fk_warehouse='.$fk_warehouse.'&productid='.$productid.'&dateday='.GETPOST('dateday', 'int').'&dateyear='.GETPOST('dateyear', 'int').'&datemonth='.GETPOST('datemonth', 'int'), 1);
	header("Location: ".$backurl);
	exit;
}
?>