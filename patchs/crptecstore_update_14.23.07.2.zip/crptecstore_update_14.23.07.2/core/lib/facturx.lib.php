<?php
/* 
 * Copyright (C) 2022		CRPTEC      <crptec.fr@gmail.com>
 *
 */

/**
 * Return a XML format for ExchangedDocumentContext.
 *
 * @param $businessProcess  le cadre de facturation (facture de mandataire, de cotraitant, de sous-traitant, piece de facturation d'un marché de travaux, etc.). 
 *                          Les codes a utiliser sont definis dans les specifications CHORUSPRO : A1 (depôt facture), A2 (depôt facture deja payee), ... 
 *                          Par defaut (en cas d'absence de ce champ), c'est le cas A1 qui s'applique
 * @param $guideLine        Pour le profil Minimum : urn:factur-x.eu:1p0:minimum
 *                          Pour le profil BASIC WL : urn:factur-x.eu:1p0:basicwl
 *                          Pour le profil BASIC :  urn:cen.eu:en16931:2017#compliant#urn:factur-x.eu:1p0:basic
 *                          Pour le Profil EN 16931 (Comfort) : urn:cen.eu:en16931:2017
 *                          Pour le Profil EXTENDED : urn:cen.eu:en16931:2017#conformant#urn:factur-x.eu:1p0:extended
 */
function facturx_ExchangedDocumentContext($businessProcess, $guideLine)
{
		$xml = '	<rsm:ExchangedDocumentContext>'."\n";
		$xml .= '		<ram:BusinessProcessSpecifiedDocumentContextParameter>'."\n";
		$xml .= '			<ram:ID>'.$businessProcess.'</ram:ID>'."\n";
		$xml .= '		</ram:BusinessProcessSpecifiedDocumentContextParameter>'."\n";
		$xml .= '		<ram:GuidelineSpecifiedDocumentContextParameter>'."\n";
		$xml .= '			<ram:ID>'.$guideLine.'</ram:ID>'."\n";
		$xml .= '		</ram:GuidelineSpecifiedDocumentContextParameter>'."\n";
		$xml .= '	</rsm:ExchangedDocumentContext>'."\n";
		return $xml;
}

/**
 * Return a XML format for ExchangedDocument.
 *
 * @info
 * ID                $object->ref  reference de la facture
 * TypeCode          380 : Facture commerciale
 *                   381 : Avoir (note de crédit)
 *                   384 : Facture rectificative
 *                   386 : Facture d'acompte
 *
 */
function facturx_ExchangedDocument($object)
{
		$type_code = 380;
		if ($object->type == 0) {$type_code = 380;}
		else if ($object->type == 1) {$type_code = 384;}
		else if ($object->type == 2) {$type_code = 381;}
		else if ($object->type == 3) {$type_code = 386;}
		else {$type_code = 0;} //type 4 (InvoiceProForma) is unknown for other application

		$xml = '	<rsm:ExchangedDocument>'."\n";
		$xml .= '			<ram:ID>'.$object->ref.'</ram:ID>'."\n";
		$xml .= '			<ram:TypeCode>'.$type_code.'</ram:TypeCode>'."\n";
		$xml .= '			<ram:IssueDateTime>'."\n";
		$xml .= '				<udt:DateTimeString format="102">'.dol_print_date($object->date, "%Y%m%d", false, $outputlangs, true).'</udt:DateTimeString>'."\n";
		$xml .= '			</ram:IssueDateTime>'."\n";
        $xml .= '			<ram:IncludedNote>'."\n";
		$xml .= '				<ram:Content>La présente facture sera payable à l\'échéance figurant sur la facture.</ram:Content>'."\n";
		$xml .= '				<ram:SubjectCode>AAI</ram:SubjectCode>'."\n";
        $xml .= '			</ram:IncludedNote>'."\n";
        $xml .= '			<ram:IncludedNote>'."\n";
		$xml .= '				<ram:Content>Taux de pénalités de retard de paiement égal à trois fois le taux d\'intérêt légal</ram:Content>'."\n";
		$xml .= '				<ram:SubjectCode>PMD</ram:SubjectCode>'."\n";
        $xml .= '			</ram:IncludedNote>'."\n";
        $xml .= '			<ram:IncludedNote>'."\n";
		$xml .= '				<ram:Content>Retard de paiement: Indemnité forfaitaire pour frais de recouvrement de 40 Euros</ram:Content>'."\n";
		$xml .= '				<ram:SubjectCode>PMT</ram:SubjectCode>'."\n";
        $xml .= '			</ram:IncludedNote>'."\n";
        $xml .= '			<ram:IncludedNote>'."\n";
		$xml .= '				<ram:Content>Aucun escompte ne sera appliqué pour paiement comptant ou anticipé</ram:Content>'."\n";
		$xml .= '				<ram:SubjectCode>AAB</ram:SubjectCode>'."\n";
        $xml .= '			</ram:IncludedNote>'."\n";
		$xml .= '	</rsm:ExchangedDocument>'."\n";
		return $xml;
}
/**
 * Return a XML format for IncludedSupplyChainTradeLineItem.
 *
 */
function facturx_IncludedSupplyChainTradeLineItem($object)
{
	$nblines = count($object->lines);
	

	// Loop on each lines
	$xml = '';
	for ($i = 0; $i < $nblines; $i++) {
		$sign = 1;
		if (isset($object->type) && $object->type == 2 && !empty($conf->global->INVOICE_POSITIVE_CREDIT_NOTE)) {
			$sign = -1;
		}
		// Unit price before discount et DOIT pas etre negatif
		$subprice = (!empty($conf->multicurrency->enabled) && $object->multicurrency_tx != 1 ? $object->lines[$i]->multicurrency_subprice : $object->lines[$i]->subprice);
		$netsubprice = $subprice / ($object->lines[$i]->situation_percent / 100);

		// Quantity et DOIT pas etre negatif
		$qty = $object->lines[$i]->qty;

		// total Ligne HT, compris remise, signee
		$total_ht = (!empty($conf->multicurrency->enabled) && $object->multicurrency_tx != 1 ? $object->lines[$i]->multicurrency_total_ht : $object->lines[$i]->total_ht);
		if (!empty($object->lines[$i]->situation_percent) && $object->lines[$i]->situation_percent > 0) {
			$total_ht = $sign * ($total_ht / ($object->lines[$i]->situation_percent / 100));
		} else {
			$total_ht = $sign * $total_ht;
		}
		
		// Remise value = subprice * qty - total_ht
		$remise = ($sign * $subprice * $object->lines[$i]->qty) - $total_ht;

		$xml .= '	<ram:IncludedSupplyChainTradeLineItem>'."\n";
		$xml .= '		<ram:AssociatedDocumentLineDocument>'."\n";
		$xml .= '			<ram:LineID>'.$object->lines[$i]->rowid.'</ram:LineID>'."\n";
		$xml .= '		</ram:AssociatedDocumentLineDocument>'."\n";
		$xml .= '		<ram:SpecifiedTradeProduct>'."\n";
		$xml .= '			<ram:GlobalID>'.$object->lines[$i]->product_ref.'</ram:GlobalID>'."\n"; //EAN 8, 12, 13, 14
		$xml .= '			<ram:Name>'.$object->lines[$i]->product_label.'</ram:Name>'."\n";
		$xml .= '		</ram:SpecifiedTradeProduct>'."\n";
		$xml .= '		<ram:SpecifiedLineTradeAgreement>'."\n";
		$xml .= '			<ram:NetPriceProductTradePrice>'."\n";
		$xml .= '				<ram:ChargeAmount currencyID="EUR">'.$netsubprice.'</ram:ChargeAmount>'."\n";
		$xml .= '			</ram:NetPriceProductTradePrice>'."\n";
		$xml .= '		</ram:SpecifiedLineTradeAgreement>'."\n";
		$xml .= '		<ram:SpecifiedLineTradeDelivery>'."\n";
        $xml .= '			<ram:BilledQuantity unitCode="PCE">'.$object->lines[$i]->qty.'</ram:BilledQuantity>'."\n";
        $xml .= '		</ram:SpecifiedLineTradeDelivery>'."\n";
		$xml .= '		<ram:SpecifiedLineTradeSettlement>'."\n";
        $xml .= '			<ram:ApplicableTradeTax>'."\n";
        $xml .= '				<ram:TypeCode>VAT</ram:TypeCode>'."\n";
        $xml .= '				<ram:CategoryCode>S</ram:CategoryCode>'."\n";
        $xml .= '				<ram:RateApplicablePercent>'.$object->lines[$i]->tva_tx.'</ram:RateApplicablePercent>'."\n";
        $xml .= '			</ram:ApplicableTradeTax>'."\n";
        $xml .= '			<ram:SpecifiedTradeSettlementLineMonetarySummation>'."\n";
        $xml .= '				<ram:LineTotalAmount currencyID="EUR">'.$total_ht.'</ram:LineTotalAmount>'."\n";
        $xml .= '			</ram:SpecifiedTradeSettlementLineMonetarySummation>'."\n";
        $xml .= '		</ram:SpecifiedLineTradeSettlement>'."\n";
		$xml .= '	</ram:IncludedSupplyChainTradeLineItem>'."\n";
	}

	return $xml;
}

/**
 * Return a XML format for ApplicableHeaderTradeAgreement. (Header information about Seller and Buyer)
 *
 */
function facturx_ApplicableHeaderTradeAgreement($object)
{
	global $conf, $langs, $mysoc;

	$object->fetch_thirdparty();
	$object->fetchObjectLinked();

	$xml = '	<ram:ApplicableHeaderTradeAgreement>'."\n";
	$xml .= '		<ram:BuyerReference>'.$object->ref_client.'</ram:BuyerReference>'."\n";
	$xml .= '		<ram:SellerTradeParty>'."\n";
	// SIRENE
	if (!empty($mysoc->idprof1)) {
		$xml .= '			<ram:ID schemeID="0002">'.$mysoc->idprof1.'</ram:ID>'."\n";
	// SIRET
	} elseif (!empty($mysoc->idprof2)) {
		$xml .= '			<ram:ID schemeID="0009">'.$mysoc->idprof2.'</ram:ID>'."\n";
	} else {
		$xml .= '			<ram:ID schemeID="">0</ram:ID>'."\n";
	}

	// SIRENE
	if (!empty($mysoc->idprof1)) {
		$xml .= '			<ram:GlobalID schemeID="0002">'.$mysoc->idprof1.'</ram:GlobalID>'."\n";
	// SIRET
	} elseif (!empty($mysoc->idprof2)) {
		$xml .= '			<ram:GlobalID schemeID="0009">'.$mysoc->idprof2.'</ram:GlobalID>'."\n";
	} else {
		$xml .= '			<ram:GlobalID schemeID="">0</ram:GlobalID>'."\n";
	}

	$xml .= '			<ram:Name>'.$mysoc->name.'</ram:Name>'."\n";
	$xml .= '			<ram:SpecifiedLegalOrganization>'."\n";
	$xml .= '				<ram:ID schemeID="0002">'.$mysoc->idprof2.'</ram:ID>'."\n";
	$xml .= '			</ram:SpecifiedLegalOrganization>'."\n";
	$xml .= '			<ram:PostalTradeAddress>'."\n";
	$xml .= '				<ram:PostcodeCode>'.$mysoc->zip.'</ram:PostcodeCode>'."\n";
	$xml .= '				<ram:LineOne>'.$mysoc->address.'</ram:LineOne>'."\n";
	$xml .= '				<ram:CityName>'.$mysoc->town.'</ram:CityName>'."\n";
	$xml .= '				<ram:CountryID>'.$mysoc->country_code.'</ram:CountryID>'."\n";
	$xml .= '			</ram:PostalTradeAddress>'."\n";
	$xml .= '			<ram:URIUniversalCommunication>'."\n";
	$xml .= '				<ram:URIID schemeID="SMTP">'.$mysoc->email.'</ram:URIID>'."\n";
	$xml .= '			</ram:URIUniversalCommunication>'."\n";
	$xml .= '			<ram:SpecifiedTaxRegistration>'."\n";
	$xml .= '				<ram:ID schemeID="VA">'.$mysoc->idprof6.'</ram:ID>'."\n";
	$xml .= '			</ram:SpecifiedTaxRegistration>'."\n";
	$xml .= '		</ram:SellerTradeParty>'."\n";
	$xml .= '		<ram:BuyerTradeParty>'."\n";
	if (!empty($object->thirdparty) && is_object($object->thirdparty)) {
		$xml .= '			<ram:ID schemeID="">0</ram:ID>'."\n";
		$xml .= '			<ram:GlobalID schemeID="">0</ram:GlobalID>'."\n";
		$xml .= '			<ram:Name>'.$object->thirdparty->name.'</ram:Name>'."\n";
		$xml .= '			<ram:SpecifiedLegalOrganization>'."\n";
		$xml .= '				<ram:ID schemeID="0002">'.$object->thirdparty->idprof2.'</ram:ID>'."\n";
		$xml .= '			</ram:SpecifiedLegalOrganization>'."\n";
		$xml .= '			<ram:PostalTradeAddress>'."\n";
		$xml .= '				<ram:PostcodeCode>'.$object->thirdparty->zip.'</ram:PostcodeCode>'."\n";
		$xml .= '				<ram:LineOne>'.$object->thirdparty->address.'</ram:LineOne>'."\n";
		$xml .= '				<ram:CityName>'.$object->thirdparty->town.'</ram:CityName>'."\n";
		$xml .= '				<ram:CountryID>'.$object->thirdparty->country_code.'</ram:CountryID>'."\n";
		$xml .= '			</ram:PostalTradeAddress>'."\n";
		$xml .= '			<ram:URIUniversalCommunication>'."\n";
		$xml .= '				<ram:URIID schemeID="SMTP">'.$object->thirdparty->email.'</ram:URIID>'."\n";
		$xml .= '			</ram:URIUniversalCommunication>'."\n";
		$xml .= '			<ram:SpecifiedTaxRegistration>'."\n";
		$xml .= '				<ram:ID schemeID="VA">'.$object->thirdparty->idprof6.'</ram:ID>'."\n";
		$xml .= '			</ram:SpecifiedTaxRegistration>'."\n";
	}
	$xml .= '		</ram:BuyerTradeParty>'."\n";
	//linked objects
	foreach ($object->linkedObjects as $objecttype => $objects) {
		if ($objecttype == 'commande') {
			$xml .= '		<ram:BuyerOrderReferencedDocument>'."\n";
			if (count($objects) == 1) {
				$elementobject = array_shift($objects);
				$xml .= '			<ram:IssuerAssignedID>'.$elementobject->ref.'</ram:IssuerAssignedID>'."\n";
			} elseif (count($objects) > 1 && count($objects) <= (getDolGlobalInt("MAXREFONDOC") ? getDolGlobalInt("MAXREFONDOC") : 10)) {
				//TODO: evolution later
			}
			$xml .= '		</ram:BuyerOrderReferencedDocument>'."\n";
		} elseif ($objecttype == 'contrat') {
			$xml .= '		<ram:ContractReferencedDocument>'."\n";
			if (count($objects) == 1) {
				$elementobject = array_shift($objects);
				$xml .= '			<ram:IssuerAssignedID>'.$elementobject->ref.'</ram:IssuerAssignedID>'."\n";
			} elseif (count($objects) > 1 && count($objects) <= (getDolGlobalInt("MAXREFONDOC") ? getDolGlobalInt("MAXREFONDOC") : 10)) {
				//TODO: evolution later
			}
			$xml .= '		</ram:ContractReferencedDocument>'."\n";
		} else {
			//do nothing in this case
		}
		
	}
	$xml .= '	</ram:ApplicableHeaderTradeAgreement>'."\n";
	return $xml;
}

/**
 * Return a XML format for ApplicableHeaderTradeDelivery. (Header information about Delivery)
 *
 */
function facturx_ApplicableHeaderTradeDelivery_basic($object)
{
	global $conf, $langs, $mysoc;
	$xml = '	<ram:ApplicableHeaderTradeDelivery>'."\n";
	$xml .= '		<ram:ActualDeliverySupplyChainEvent>'."\n";
	$xml .= '			<ram:OccurrenceDateTime>'."\n";
	$xml .= '				<udt:DateTimeString format="102">'.dol_print_date($object->delivery_date, "%Y%m%d", false, $outputlangs, true).'</udt:DateTimeString>'."\n";
	$xml .= '			</ram:OccurrenceDateTime>'."\n";
	$xml .= '		</ram:ActualDeliverySupplyChainEvent>'."\n";
	$xml .= '	</ram:ApplicableHeaderTradeDelivery>'."\n";
	return $xml;
}

/**
 * Return a XML format for ApplicableHeaderTradeDelivery. (Header information about Delivery)
 *
 * TODO: to be completed
 */
function facturx_ApplicableHeaderTradeDelivery_en16931($object)
{
	global $conf, $langs, $mysoc;

	$object->fetch_thirdparty();
	$object->fetchObjectLinked();
	$addedDelivery = 0;

	$xml = '	<ram:ApplicableHeaderTradeDelivery>'."\n";
	foreach ($object->linkedObjects as $objecttype => $objects) {
		if ($objecttype == 'shipping') {
			$addedDelivery = 1;
			$outputlangs->loadLangs(array("orders", "sendings"));
			if (count($objects) == 1) {
				$elementobject = array_shift($objects);
				// TODO add shiping address
				$xml .= '		<ram:DespatchAdviceReferencedDocument>'."\n";
				$xml .= '			<ram:IssuerAssignedID>'.$elementobject->ref.'</ram:IssuerAssignedID>'."\n";
				$xml .= '		</ram:DespatchAdviceReferencedDocument>'."\n";
			} elseif (count($objects) > 1 && count($objects) <= (getDolGlobalInt("MAXREFONDOC") ? getDolGlobalInt("MAXREFONDOC") : 10)) {
				// TODO: evolution later
			}
		}
	}

	// no Shipping address, add third party address
	if ($addedDelivery == 0 && !empty($object->thirdparty) && is_object($object->thirdparty))
	{
		$xml .= '		<ram:ShipToTradeParty>'."\n";
		$xml .= '			<ram:ID schemeID="0002">'.$object->thirdparty->idprof2.'</ram:ID>'."\n";
		$xml .= '			<ram:PostalTradeAddress>'."\n";
		$xml .= '				<ram:PostcodeCode>'.$object->thirdparty->zip.'</ram:PostcodeCode>'."\n";
		$xml .= '				<ram:LineOne>'.$object->thirdparty->address.'</ram:LineOne>'."\n";
		$xml .= '				<ram:CityName>'.$object->thirdparty->town.'</ram:CityName>'."\n";
		$xml .= '				<ram:CountryID>'.$object->thirdparty->country_code.'</ram:CountryID>'."\n";
		$xml .= '			</ram:PostalTradeAddress>'."\n";
		$xml .= '		</ram:ShipToTradeParty>'."\n";
	}

	$xml .= '		<ram:ActualDeliverySupplyChainEvent>'."\n";
	$xml .= '			<ram:OccurrenceDateTime>'."\n";
	$xml .= '				<udt:DateTimeString format="102">'.dol_print_date($object->delivery_date, "%Y%m%d", false, $outputlangs, true).'</udt:DateTimeString>'."\n";
	$xml .= '			</ram:OccurrenceDateTime>'."\n";
	$xml .= '		</ram:ActualDeliverySupplyChainEvent>'."\n";
	if ($addedDelivery == 0)
	{
		$xml .= '		<ram:DespatchAdviceReferencedDocument>'."\n";
		$xml .= '			<ram:IssuerAssignedID>BL45</ram:IssuerAssignedID>'."\n";
		$xml .= '		</ram:DespatchAdviceReferencedDocument>'."\n";
	}
	$xml .= '	</ram:ApplicableHeaderTradeDelivery>'."\n";
	return $xml;
}

/**
 * Return a XML format for ApplicableHeaderTradeSettlement. Paiement information (tax incl)
 *
 * En particulier, les codes suivants peuvent etre utiliss:
 * 10 : Especes
 * 20 : Cheque
 * 30 : Virement (inclut Virement SEPA pour CHORUSPRO)
 * 42 : Paiement sur compte bancaire
 * 48 : Paiement par carte bancaire
 * 49 : prelevement (inclut Prélèvement SEPA pour CHORUSPRO)
 * 57 : Moyen de paiement deja defini entre les parties
 * 58 : Virement SEPA (non utilise pour CHORUSPRO : code 30)
 * 59 : Prelevement SEPA (non utilise pour CHORUSPRO : code 49)
 * 97 : Report
 * ZZZ : moyen de paiementprovisoire défini entre partenaires commerciaux
 *
 *
 *
 * DueDateTypeCode:
 * 5 : Date de la facture (TVA sur DEBITS)
 * 29 : Date de livraison (TVA sur DEBITS)
 * 72 : Date de paiement (TVA sur ENCAISSEMENTS)
 *
 *
 *
 * CategoryCode
 * Les codes de categorie de TVA sont les suivants :
 * S = Taux de TVA standard
 * Z = Taux de TVA egal à 0 (non applicable en France)
 * E = Exempte de TVA
 * AE = Autoliquidation de TVA
 * K = Autoliquidation pour cause de livraison intracommunautaire
 * G = Exempte de TVA pour Export hors UE
 * O = Hors du périmetre d'application de la TVA
 * L = Iles Canaries
 * M = Ceuta et Mellila
 *
 *
 * TODO: to be completed
 */ 
function facturx_ApplicableHeaderTradeSettlement($object, $model='basic')
{
	global $conf, $langs, $mysoc, $db;

	$nblines = count($object->lines);
	$tva = array();
	$tva_array = array();
	$ht_array = array();
	$ht_total_ligne = 0;
	for ($i = 0; $i < $nblines; $i++) {
		$tvaligne = 0;
		$htligne = 0;
		$sign = 1;
		if (isset($object->type) && $object->type == 2 && !empty($conf->global->INVOICE_POSITIVE_CREDIT_NOTE)) {
			$sign = -1;
		}
		// Collection of totals by value of VAT in $this->tva["taux"]=total_tva
		$prev_progress = $object->lines[$i]->get_prev_progress($object->id);
		if ($prev_progress > 0 && !empty($object->lines[$i]->situation_percent)) { // Compute progress from previous situation
			if (!empty($conf->multicurrency->enabled) && $object->multicurrency_tx != 1) {
				$tvaligne = $sign * $object->lines[$i]->multicurrency_total_tva * ($object->lines[$i]->situation_percent - $prev_progress) / $object->lines[$i]->situation_percent;
				$htligne = $sign * $object->lines[$i]->multicurrency_total_ht * ($object->lines[$i]->situation_percent - $prev_progress) / $object->lines[$i]->situation_percent;
			} else {
				$tvaligne = $sign * $object->lines[$i]->total_tva * ($object->lines[$i]->situation_percent - $prev_progress) / $object->lines[$i]->situation_percent;
				$htligne = $sign * $object->lines[$i]->total_ht * ($object->lines[$i]->situation_percent - $prev_progress) / $object->lines[$i]->situation_percent;
			}
		} else {
			if (!empty($conf->multicurrency->enabled) && $object->multicurrency_tx != 1) {
				$tvaligne = $sign * $object->lines[$i]->multicurrency_total_tva;
				$htligne = $sign * $object->lines[$i]->multicurrency_total_ht;
			} else {
				$tvaligne = $sign * $object->lines[$i]->total_tva;
				$htligne = $sign * $object->lines[$i]->total_tva;
			}
		}

		$vatrate = (string) $object->lines[$i]->tva_tx;
		if (($object->lines[$i]->info_bits & 0x01) == 0x01) {
			$vatrate .= '*';
		}

		if (!isset($tva[$vatrate])) {
			$tva[$vatrate] = 0;
		}
		$tva[$vatrate] += $tvaligne;	// ->tva is abandonned, we use now ->tva_array that is more complete
		$vatcode = $object->lines[$i]->vat_src_code;
		if (empty($tva_array[$vatrate.($vatcode ? ' ('.$vatcode.')' : '')]['amount'])) {
			$tva_array[$vatrate.($vatcode ? ' ('.$vatcode.')' : '')]['amount'] = 0;
		}
		$tva_array[$vatrate.($vatcode ? ' ('.$vatcode.')' : '')] = array('vatrate'=>$vatrate, 'vatcode'=>$vatcode, 'amount'=> $tva_array[$vatrate.($vatcode ? ' ('.$vatcode.')' : '')]['amount'] + $tvaligne);

		if (empty($ht_array[$vatrate.($vatcode ? ' ('.$vatcode.')' : '')]['amount'])) {
			$ht_array[$vatrate.($vatcode ? ' ('.$vatcode.')' : '')]['amount'] = 0;
		}
		$ht_array[$vatrate.($vatcode ? ' ('.$vatcode.')' : '')] = array('vatrate'=>$vatrate, 'vatcode'=>$vatcode, 'amount'=> $ht_array[$vatrate.($vatcode ? ' ('.$vatcode.')' : '')]['amount'] + $htligne);
		//total HT tous les lignes
		$ht_total_ligne = $htligne + $ht_total_ligne;
	}

	$xml = '	<ram:ApplicableHeaderTradeSettlement>'."\n";
	$xml .= '		<ram:InvoiceCurrencyCode>'.$conf->currency.'</ram:InvoiceCurrencyCode>'."\n";
	$xml .= '		<ram:SpecifiedTradeSettlementPaymentMeans>'."\n";
	// show iban info if we have, and bic info if we are in mode en16931
	if ($object->fk_account > 0 || $object->fk_bank > 0 || !empty($conf->global->FACTURE_RIB_NUMBER)) {
		$bankid = ($object->fk_account <= 0 ? $conf->global->FACTURE_RIB_NUMBER : $object->fk_account);
		if ($object->fk_bank > 0) {
			$bankid = $object->fk_bank;
		}
		$account = new Account($db);
		$account->fetch($bankid);
		$xml .= '			<ram:TypeCode>42</ram:TypeCode>'."\n";
		if(!empty($account->iban)) {
			$xml .= '			<ram:PayeePartyCreditorFinancialAccount>'."\n";
			$xml .= '				<ram:IBANID>'.$account->iban.'</ram:IBANID>'."\n";
			$xml .= '			</ram:PayeePartyCreditorFinancialAccount>'."\n";

			if ($model == 'en16931')
			{
				if (!empty($account->bic))
				{
					$xml .= '			<ram:PayeeSpecifiedCreditorFinancialInstitution>'."\n";
					$xml .= '				<ram:BICID>'.$account->bic.'</ram:BICID>'."\n";
					$xml .= '			</ram:PayeeSpecifiedCreditorFinancialInstitution>'."\n";
				} else {
					$xml .= '			<ram:PayeeSpecifiedCreditorFinancialInstitution>'."\n";
					$xml .= '				<ram:BICID></ram:BICID>'."\n";
					$xml .= '			</ram:PayeeSpecifiedCreditorFinancialInstitution>'."\n";
				}
			}
		} else {
			$xml .= '			<ram:PayeePartyCreditorFinancialAccount>'."\n";
			$xml .= '				<ram:IBANID></ram:IBANID>'."\n";
			$xml .= '			</ram:PayeePartyCreditorFinancialAccount>'."\n";
			$xml .= '			<ram:PayeeSpecifiedCreditorFinancialInstitution>'."\n";
			$xml .= '				<ram:BICID></ram:BICID>'."\n";
			$xml .= '			</ram:PayeeSpecifiedCreditorFinancialInstitution>'."\n";
		}
	} else {
		$xml .= '			<ram:PayeePartyCreditorFinancialAccount>'."\n";
		$xml .= '				<ram:IBANID></ram:IBANID>'."\n";
		$xml .= '			</ram:PayeePartyCreditorFinancialAccount>'."\n";
		$xml .= '			<ram:PayeeSpecifiedCreditorFinancialInstitution>'."\n";
		$xml .= '				<ram:BICID></ram:BICID>'."\n";
		$xml .= '			</ram:PayeeSpecifiedCreditorFinancialInstitution>'."\n";
	}

	$xml .= '		</ram:SpecifiedTradeSettlementPaymentMeans>'."\n";

	foreach ($tva_array as $tvakey => $tvaval) {
		$xml .= '		<ram:ApplicableTradeTax>'."\n";
		$xml .= '			<ram:CalculatedAmount currencyID="EUR">'.price2num($tvaval['amount'], 'MT').'</ram:CalculatedAmount>'."\n";
		$xml .= '			<ram:TypeCode>VAT</ram:TypeCode>'."\n";
		$xml .= '			<ram:BasisAmount currencyID="EUR">'.price2num($htval['amount'], 'MT').'</ram:BasisAmount>'."\n";
		$xml .= '			<ram:CategoryCode>S</ram:CategoryCode>'."\n";
		$xml .= '			<ram:DueDateTypeCode>5</ram:DueDateTypeCode>'."\n";
		$xml .= '			<ram:RateApplicablePercent>'.$tvaval['vatrate'].'</ram:RateApplicablePercent>'."\n";
		$xml .= '		</ram:ApplicableTradeTax>'."\n";
	}

	if ($model == 'en16931')
	{
		// Loop on each discount available (deposits and credit notes and excess of payment included)
		$sql = "SELECT re.rowid, re.amount_ht, re.tva_tx, re.multicurrency_amount_ht, re.amount_tva, re.multicurrency_amount_tva,  re.amount_ttc, re.multicurrency_amount_ttc,";
		$sql .= " re.description, re.fk_facture_source,";
		$sql .= " f.type, f.datef";
		$sql .= " FROM ".MAIN_DB_PREFIX."societe_remise_except as re, ".MAIN_DB_PREFIX."facture as f";
		$sql .= " WHERE re.fk_facture_source = f.rowid AND re.fk_facture = ".((int) $object->id);
		$resql = $db->query($sql);
		$invoice = new Facture($db);
		if ($resql) {
			$num = $db->num_rows($resql);
			$i = 0;
			while ($i < $num) {
				$obj = $db->fetch_object($resql);
				$remise_ht = (!empty($conf->multicurrency->enabled) && $object->multicurrency_tx != 1) ? $obj->multicurrency_amount_ht : $obj->amount_ht;
				
				$xml .= '		<ram:SpecifiedTradeAllowanceCharge>'."\n";
				$xml .= '			<ram:ChargeIndicator>'."\n";
				$xml .= '				<udt:Indicator>false</udt:Indicator>'."\n";
				$xml .= '			<ram:ChargeIndicator>'."\n";
				$xml .= '			<ram:CalculationPercent>0</ram:CalculationPercent>'."\n";
				$xml .= '			<ram:BasisAmount currencyID="EUR"></ram:BasisAmount>'."\n";
				$xml .= '			<ram:ActualAmount currencyID="EUR">'.$remise_ht.'</ram:ActualAmount>'."\n";
				$xml .= '			<ram:Reason>'.$obj->description.'</ram:Reason>'."\n";
				$xml .= '			<ram:CategoryTradeTax>'."\n";
				$xml .= '				<ram:TypeCode></ram:TypeCode>'."\n";
				$xml .= '				<ram:CategoryCode></ram:CategoryCode>'."\n";
				$xml .= '				<ram:DueDateTypeCode></ram:DueDateTypeCode>'."\n";
				$xml .= '				<ram:RateApplicablePercent>'.$obj->tva_tx.'</ram:RateApplicablePercent>'."\n";
				$xml .= '			</ram:CategoryTradeTax>'."\n";
				$xml .= '		</ram:SpecifiedTradeAllowanceCharge>'."\n";


				$i++;
			}
		} else {
			$xml .= '		<ram:SpecifiedTradeAllowanceCharge>'."\n";
			$xml .= '			<ram:ChargeIndicator>'."\n";
			$xml .= '				<udt:Indicator>false</udt:Indicator>'."\n";
			$xml .= '			<ram:ChargeIndicator>'."\n";
			$xml .= '			<ram:CalculationPercent>0</ram:CalculationPercent>'."\n";
			$xml .= '			<ram:BasisAmount currencyID="EUR"></ram:BasisAmount>'."\n";
			$xml .= '			<ram:ActualAmount currencyID="EUR"></ram:ActualAmount>'."\n";
			$xml .= '			<ram:Reason></ram:Reason>'."\n";
			$xml .= '			<ram:CategoryTradeTax>'."\n";
			$xml .= '				<ram:TypeCode></ram:TypeCode>'."\n";
			$xml .= '				<ram:CategoryCode></ram:CategoryCode>'."\n";
			$xml .= '				<ram:DueDateTypeCode></ram:DueDateTypeCode>'."\n";
			$xml .= '				<ram:RateApplicablePercent>0</ram:RateApplicablePercent>'."\n";
			$xml .= '			</ram:CategoryTradeTax>'."\n";
			$xml .= '		</ram:SpecifiedTradeAllowanceCharge>'."\n";
		}
	}

	$xml .= '		<ram:SpecifiedTradePaymentTerms>'."\n";
    $xml .= '			<ram:DueDateDateTime>'."\n";
    $xml .= '				<udt:DateTimeString format="102">'.dol_print_date($object->date_lim_reglement, "%Y%m%d", false, $outputlangs, true).'</udt:DateTimeString>'."\n";
    $xml .= '			</ram:DueDateDateTime>'."\n";
	$xml .= '		</ram:SpecifiedTradePaymentTerms>'."\n";

	$total_ht = ((!empty($conf->multicurrency->enabled) && isset($object->multicurrency_tx) && $object->multicurrency_tx != 1) ? $object->multicurrency_total_ht : $object->total_ht);
	$remise = (!empty($object->remise) ? $object->remise : 0);
	$total_ttc = (!empty($conf->multicurrency->enabled) && $object->multicurrency_tx != 1) ? $object->multicurrency_total_ttc : $object->total_ttc;
	
	$retainedWarranty = $object->getRetainedWarrantyAmount();
	$billedWithRetainedWarranty = $object->total_ttc - $retainedWarranty;
	
	$xml .= '		<ram:SpecifiedTradeSettlementHeaderMonetarySummation>'."\n";
	$xml .= '			<ram:LineTotalAmount currencyID="EUR">'.$ht_total_ligne.'</ram:LineTotalAmount>'."\n";
	$xml .= '			<ram:AllowanceTotalAmount currencyID="EUR">'.$remise.'</ram:AllowanceTotalAmount>'."\n";
	$xml .= '			<ram:TaxBasisTotalAmount currencyID="EUR">'.$total_ht.'</ram:TaxBasisTotalAmount>'."\n";
	$xml .= '			<ram:TaxTotalAmount currencyID="EUR">'.$object->total_tva.'</ram:TaxTotalAmount>'."\n";
	$xml .= '			<ram:GrandTotalAmount currencyID="EUR">'.$total_ttc.'</ram:GrandTotalAmount>'."\n";
	$xml .= '			<ram:TotalPrepaidAmount currencyID="EUR">'.$retainedWarranty.'</ram:TotalPrepaidAmount>'."\n";
	$xml .= '			<ram:DuePayableAmount currencyID="EUR">'.$billedWithRetainedWarranty.'</ram:DuePayableAmount>'."\n";
	$xml .= '		</ram:SpecifiedTradeSettlementHeaderMonetarySummation>'."\n";
	$xml .= '	</ram:ApplicableHeaderTradeSettlement>'."\n";
	return $xml;
}
/**
 * Return 0 if xml file is created in basic mode, -1 if KO
 *
 * @param   $object   invoice object or order object
 */
function facturx_basic($object) 
{
	global $db, $conf, $langs;

    $dir = (empty($conf->facture->multidir_output[$conf->entity]) ? $conf->facture->dir_output : $conf->facture->multidir_output[$conf->entity])."/".$objectref;
	$ref = dol_sanitizeFileName($object->ref);

	$filepath = $dir."/".$ref."/".$ref.".xml";
	$handle = fopen($filepath, "wt");
	if (!$handle) {
		$langs->load("errors");
		$error = $langs->trans("ErrorFailToCreateFile", $filePath);
		error_log("ERROR: ".$error);
		return -1;
	} else {
		$xml = '<rsm:CrossIndustryInvoice xmlns:qdt="urn:un:unece:uncefact:data:standard:QualifiedDataType:100" xmlns:ram="urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100" xmlns:rsm="urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100" xmlns:udt="urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'."\n";
		$xml .= 	facturx_ExchangedDocumentContext('A1', 'urn:factur-x.eu:1p0:basic');
		$xml .= 	facturx_ExchangedDocument($object);
		$xml .= '	<rsm:SupplyChainTradeTransaction>'."\n";
		$xml .= 		facturx_IncludedSupplyChainTradeLineItem($object);
		$xml .= 		facturx_ApplicableHeaderTradeAgreement($object);
		$xml .= 		facturx_ApplicableHeaderTradeDelivery_basic($object);
		$xml .= 		facturx_ApplicableHeaderTradeSettlement($object);
		$xml .= '	</rsm:SupplyChainTradeTransaction>'."\n";
		$xml .= '</rsm:CrossIndustryInvoice>';
		fwrite($handle, $xml);
	}
	// Close file
	fclose($handle);
	return 0;
}

/**
 * Return 0 if xml file is created in basic mode, -1 if KO
 *
 * @param   $object   invoice object or order object
 */
function facturx_en16931($object) 
{
	global $db, $conf, $langs;

    $dir = (empty($conf->facture->multidir_output[$conf->entity]) ? $conf->facture->dir_output : $conf->facture->multidir_output[$conf->entity])."/".$objectref;
	$ref = dol_sanitizeFileName($object->ref);

	$filepath = $dir."/".$ref."/".$ref.".xml";
	$handle = fopen($filepath, "wt");
	if (!$handle) {
		$langs->load("errors");
		$error = $langs->trans("ErrorFailToCreateFile", $filePath);
		error_log("ERROR: ".$error);
		return -1;
	} else {
		$xml = '<rsm:CrossIndustryInvoice xmlns:qdt="urn:un:unece:uncefact:data:standard:QualifiedDataType:100" xmlns:ram="urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100" xmlns:rsm="urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100" xmlns:udt="urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'."\n";
		$xml .= 	facturx_ExchangedDocumentContext('A1', 'urn:cen.eu:en16931:2017');
		$xml .= 	facturx_ExchangedDocument($object);
		$xml .= '	<rsm:SupplyChainTradeTransaction>'."\n";
		$xml .= 		facturx_IncludedSupplyChainTradeLineItem($object);
		$xml .= 		facturx_ApplicableHeaderTradeAgreement($object);
		$xml .= 		facturx_ApplicableHeaderTradeDelivery_en16931($object);
		$xml .= 		facturx_ApplicableHeaderTradeSettlement($object, 'en16931');
		$xml .= '	</rsm:SupplyChainTradeTransaction>'."\n";
		$xml .= '</rsm:CrossIndustryInvoice>';
		fwrite($handle, $xml);
	}
	// Close file
	fclose($handle);
	return 0;
}
?> 