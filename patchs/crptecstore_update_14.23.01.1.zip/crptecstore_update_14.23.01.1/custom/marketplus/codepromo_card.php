<?php
/* 
 * Copyright (C) 2022		CRPTEC      <crptec.fr@gmail.com>
 *
 */
// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) {
	$res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
}
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
	$i--; $j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
}
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) {
	$res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
}
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) {
	$res = @include "../main.inc.php";
}
if (!$res && file_exists("../../main.inc.php")) {
	$res = @include "../../main.inc.php";
}
if (!$res && file_exists("../../../main.inc.php")) {
	$res = @include "../../../main.inc.php";
}
if (!$res && file_exists("../../../../main.inc.php")) {
	$res = @include "../../../../main.inc.php";
}
if (!$res) {
	die("Include of main fails");
}

require_once DOL_DOCUMENT_ROOT.'/projet/class/project.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.form.class.php';
require_once DOL_DOCUMENT_ROOT.'/user/class/usergroup.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formfile.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/CMailFile.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formmail.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/doleditor.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/date.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/extrafields.class.php';

require_once 'class/promotion_code.class.php';

// Get parameters
$action = GETPOST('action', 'aZ09');
$cancel = GETPOST('cancel', 'alpha');
$confirm = GETPOST('confirm', 'alpha');
$socid = GETPOST('socid', 'int');

$id = GETPOST('id', 'int');
$fusercreate = (GETPOST('fusercreate', 'int') ?GETPOST('fusercreate', 'int') : $user->id);
$fusercreate = ($fusercreate == 0 ? $user->id : $fusercreate);
// Load translation files required by the page
$langs->loadLangs(array("marketplus@marketplus", "other", "mails"));
$error = 0;

$now = dol_now();

$childids = $user->getAllChildIds(1);

$object = new PromotionCode($db);
$extrafields = new ExtraFields($db);
// fetch optionals attributes and labels
$extrafields->fetch_name_optionals_label($object->table_element);

if ($id > 0) {
	$object->fetch($id);

	// Check current user can read this promotion code
	$canread = 0;
	if (!empty($user->rights->marketplus->codepromo->read)) {
		$canread = 1;
	}
	if (!empty($user->rights->marketplus->codepromo->read) && in_array($object->fk_user_create, $childids)) {
		$canread = 1;
	}
	if (!$canread) {
		accessforbidden();
	}
}

// Initialize technical object to manage hooks of page. Note that conf->hooks_modules contains array of hook context
$hookmanager->initHooks(array('promotioncodecard', 'globalcard'));

$cancreate = 0;
if (!empty($user->rights->marketplus->codepromo->write) && in_array($fusercreate, $childids)) {
	$cancreate = 1;
}

$candelete = 0;
if (!empty($user->rights->marketplus->codepromo->delete)) {
	$candelete = 1;
}

$createbarcode = empty($conf->barcode->enabled) ? 0 : 1;
$showbarcode = $createbarcode;
/*
 * Actions
 */
$parameters = array('socid' => $socid);
$reshook = $hookmanager->executeHooks('doActions', $parameters, $object, $action); // Note that $action and $object may have been modified by some hooks
if ($reshook < 0) {
	setEventMessages($hookmanager->error, $hookmanager->errors, 'errors');
}

if (empty($reshook)) {
	$backurlforlist = dol_buildpath('/marketplus/codepromo_list.php?', 1);
	if (empty($backtopage) || ($cancel && empty($id))) {
		if (empty($backtopage) || ($cancel && strpos($backtopage, '__ID__'))) {
			if (empty($id) && (($action != 'add' && $action != 'create') || $cancel)) {
				$backtopage = $backurlforlist;
			} else {
				$backtopage =  dol_buildpath('/marketplus/codepromo_card.php?id=', 1).((!empty($id) && $id > 0) ? $id : '__ID__');
			}
		}
	}

	if ($cancel) {
		if (!empty($backtopageforcancel)) {
			header("Location: ".$backtopageforcancel);
			exit;
		} elseif (!empty($backtopage)) {
			header("Location: ".$backtopage);
			exit;
		}
		$action = '';
	}

	// Add create promotion code
	if ($action == 'add') {
		// If no right to create a promotion
		if (!$cancreate) {
			$error++;
			setEventMessages($langs->trans('CantCreatePromo'), null, 'errors');
			$action = 'create';
		}

		if (!$error) {
			$object = new PromotionCode($db);

			$db->begin();

			$object->barcode_type = GETPOST('fk_barcode_type');
			$barcode = GETPOST('barcode');

			$type = GETPOST('type', 'int');
			$fk_user_create = GETPOST('fk_user_create', 'int');
			$fk_project = GETPOST('fk_project', 'int');
			$fk_user_benef = GETPOST('socid', 'int'); //third party
			$promo_value = price2num(GETPOST('promo_value','alpha'));
			$date_start = dol_mktime(0, 0, 0, GETPOST('date_start_month'), GETPOST('date_start_day'), GETPOST('date_start_year'));
			$date_end = dol_mktime(23, 59, 59, GETPOST('date_end_month'), GETPOST('date_end_day'), GETPOST('date_end_year'));
			

			// If no code
			if (empty($barcode)) {
				setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv("Code")), null, 'errors');
				$error++;
				$action = 'create';
			}
			// If no type
			if ($type <= 0) {
				setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv("Type")), null, 'errors');
				$error++;
				$action = 'create';
			}
			// If no promo_value
			if ($promo_value < 0) {
				setEventMessages($langs->trans("ErrorFieldRequired", $langs->transnoentitiesnoconv("PromoValue")), null, 'errors');
				$error++;
				$action = 'create';
			}
			// If no start date
			if (empty($date_start)) {
				setEventMessages($langs->trans("NoDateDebut"), null, 'errors');
				$error++;
				$action = 'create';
			}
			// If no end date
			if (empty($date_end)) {
				setEventMessages($langs->trans("NoDateFin"), null, 'errors');
				$error++;
				$action = 'create';
			}
			if (empty($fk_project) || $fk_project == 0) {
				setEventMessages($langs->trans("ProjectIdError"), null, 'errors');
				$error++;
				$action = 'create';
			}

			$result = 0;

			if (!$error) {
				dol_syslog("code promode card: NO ERROR ", LOG_DEBUG);
				$object->barcode = $barcode;
				$object->fk_user_create = $fk_user_create;
				$object->fk_user_benef = $fk_user_benef;
				$object->date_start = $date_start;
				$object->date_end = $date_end;
				$object->type = $type;
				$object->promo_value = $promo_value;
				$object->fk_project = $fk_project;

				$result = $object->create($user);
				if ($result <= 0) {
					setEventMessages($object->error, $object->errors, 'errors');
					$error++;
				}
			}

			// If no SQL error we redirect to the request card
			if (!$error) {
				$db->commit();

				header('Location: '.$_SERVER["PHP_SELF"].'?id='.$object->id);
				exit;
			} else {
				dol_syslog("code promode card: ERROR detected", LOG_DEBUG);
				$db->rollback();
			}
		}
	}

	// If delete of request
	if ($action == 'confirm_delete' && GETPOST('confirm') == 'yes' && $candelete) {
		$error = 0;

		$db->begin();

		$object->fetch($id);
		// If this is a active
		if ($object->active) {
			$result = $object->delete($user);
		} else {
			$error++;
			setEventMessages($langs->trans('BadStatusOfObject'), null, 'errors');
			$action = '';
		}

		if (!$error) {
			$db->commit();
			header('Location: codepromo_list.php?restore_lastsearch_values=1');
			exit;
		} else {
			$db->rollback();
		}
	}
}


/*
 * View
 */
$form = new Form($db);
$soc = new Societe($db);
$projectstatic = new Project($db);

$title = $langs->trans('PromotionCode');
$help_url = '';
//bein of page
llxHeader('', $title, $help_url);
print load_fiche_titre($langs->trans("PromotionCode"), '', 'promotion@marketplus');

if (empty($id) || $action == 'create' || $action == 'add') {
	// If user has no permission to create a promotion code
	if (in_array($fusercreate, $childids) && empty($user->rights->marketplus->codepromo->write)) {
		$errors[] = $langs->trans('CantCreatePromo');
	} else {
		// Form to add a promotion code
		print load_fiche_titre($langs->trans('MenuAddPromo'), '', '');

		// Error management
		if (GETPOST('error')) {
			switch (GETPOST('error')) {
				case 'datefin':
					$errors[] = $langs->trans('ErrorEndDatePromo');
					break;
				case 'SQL_Create':
					$errors[] = $langs->trans('ErrorSQLCreatePromo').' <b>'.htmlentities($_GET['msg']).'</b>';
					break;
				case 'CantCreate':
					$errors[] = $langs->trans('CantCreatePromo');
					break;
				case 'nodatedebut':
					$errors[] = $langs->trans('NoDateDebut');
					break;
				case 'nodatefin':
					$errors[] = $langs->trans('NoDateFin');
					break;
				case 'DureePromo':
					$errors[] = $langs->trans('ErrorDureePromo');
					break;
				case 'AlreadyPromo':
					$errors[] = $langs->trans('AlreadyPromo');
					break;
			}

			setEventMessages($errors, null, 'errors');
		}

		// Formulaire de demande
		print '<form method="POST" action="'.$_SERVER['PHP_SELF'].'?action=add" name="createPromo">'."\n";
		print '<input type="hidden" name="token" value="'.newToken().'" />'."\n";
		print '<input type="hidden" name="action" value="add" />'."\n";

		print dol_get_fiche_head();

		print '<table class="border centpercent">';
		print '<tbody>';

		// User create promo
		print '<tr>';
		print '<td class="titlefield fieldrequired">'.$langs->trans("User").'</td>';
		print '<td>';
		print img_picto('', 'user', 'class="paddingrighonly"').' '.$user->lastname.' '.$user->firstname.'<input type="hidden" id="fk_user_create" name="fk_user_create" value="'.($fusercreate? $fusercreate: $ $user->id).'" />';
		//$noactive = 1; 
		//print img_picto('', 'user', 'class="paddingrighonly"').$form->select_dolusers($fusercreate, 'fk_user_create', 1, '', 0, '', '', 0, 0, 0, 'AND employee=1', 0, '', 'maxwidth300', $noactive);
		print '</td>';
		print '</tr>';

		// Thirdparty
		print '<tr>';
		print '<td>'.$langs->trans('Customer').'</td>';
		if ($socid > 0) {
			$result = $soc->fetch($socid );
			if ($result <= 0) {
				dol_print_error($db, $soc->error);
				exit;
			}
			print '<td>';
			print $soc->getNomUrl(1, 'customer');
			print '<input type="hidden" name="socid" value="'.$soc->id.'">';
			print '</td>';
		} else {
			print '<td>';
			print img_picto('', 'company').$form->select_company('', 'socid', '(s.client = 1 OR s.client = 2 OR s.client = 3)', 'SelectThirdParty', 0, 0, null, 0, 'minwidth175 maxwidth500 widthcentpercentminusxx');
			// reload page to retrieve customer informations
			if (empty($conf->global->RELOAD_PAGE_ON_CUSTOMER_CHANGE_DISABLED)) {
				print '<script type="text/javascript">
				$(document).ready(function() {
					$("#socid").change(function() {
						console.log("We have changed the company - Reload page");
						var socid = $(this).val();
						// reload page
						$("input[name=action]").val("create");
						$("form[name=crea_commande]").submit();
					});
				});
				</script>';
			}
			print ' <a href="'.DOL_URL_ROOT.'/societe/card.php?action=create&client=3&fournisseur=0&backtopage='.urlencode($_SERVER["PHP_SELF"].'?action=create').'"><span class="fa fa-plus-circle valignmiddle paddingleft" title="'.$langs->trans("AddThirdParty").'"></span></a>';
			print '</td>';
		}
		print '</tr>'."\n";

		//project
		$arrayprojets = array();
		$db->begin();
		$sql = "SELECT p.rowid, p.ref, p.title FROM ". MAIN_DB_PREFIX . "projet p WHERE p.fk_statut=1";
		$resql = $db->query($sql);
		if ($resql) {
			if ($db->num_rows($resql) > 0) {
				$nump = $db->num_rows($resql);
				$j=0;
				while ($j < $nump) {
					$pobj = $db->fetch_object($resql);
					$arrayprojets[$pobj->rowid] = $pobj->ref.' '.$pobj->title;
					$j++;
				}
			}
		}
		print '<tr>';
		print '<td>'.$langs->trans("Project").'</td>';
		print '<td>';
		print $form->selectarray('fk_project', $arrayprojets, (GETPOST('fk_project', 'int') ?GETPOST('fk_project', 'int') : ''), 1, 0, 0, '', 0, 0, 0, '', '', true);
		print '</td>';
		print '</tr>';
		
		// Type
		print '<tr>';
		print '<td class="fieldrequired">'.$langs->trans("Type").'</td>';
		print '<td>';
		$arraytypepromo = array();
		$arraytypepromo[1] = $langs->trans("TypePromoAmount");
		$arraytypepromo[2] = $langs->trans("TypePromoPercent");
		$arraytypepromo[3] = $langs->trans("TypePromoLineAmount");
		$arraytypepromo[4] = $langs->trans("TypePromoLinePercent");
		print $form->selectarray('type', $arraytypepromo, (GETPOST('type', 'int') ?GETPOST('type', 'int') : ''), 1, 0, 0, '', 0, 0, 0, '', '', true);
		print '</td>';
		print '</tr>';

		//barcode
		if ($showbarcode) {
			// Barcode type
			print '<tr><td>'.$langs->trans('BarcodeType').'</td><td>';
			if (GETPOSTISSET('fk_barcode_type')) {
				$fk_barcode_type = GETPOST('fk_barcode_type')?GETPOST('fk_barcode_type'):0;
			} else {
				$fk_barcode_type = 2;//EAN13
			}
			/*
			require_once DOL_DOCUMENT_ROOT.'/core/class/html.formbarcode.class.php';
			$formbarcode = new FormBarCode($db);
			print $formbarcode->selectBarcodeType($fk_barcode_type, 'fk_barcode_type', 1);
			*/
			print '<input type="hidden" name="fk_barcode_type" id="fk_barcode_type" value="'.$fk_barcode_type.'"> EAN13';
			print '</td>';
			print '</tr><tr>';
			print '<td class="titlefield fieldrequired">'.$langs->trans("BarcodeValue").'</td><td>';
			$tmpcode = GETPOSTISSET('barcode') ? GETPOST('barcode') : $object->barcode;
			print '<input class="maxwidth100" type="text" name="barcode" id="barcode" value="'.dol_escape_htmltag($tmpcode).'">'.img_picto($langs->trans('Generate'), 'refresh', 'id="generate_barcode" class="linkobject"');
			print '</td></tr>';
		}

		// promo_value
		print '<tr>';
		print '<td class="titlefield fieldrequired">'.$langs->trans("ValuePromo").'</td>';
		print '<td class="tdtop">';
		print '<input name="promo_value" id="promo_value" class="minwidth75 maxwidth100" value="'.GETPOST("promo_value").'">&nbsp;';
		print '</td></tr>';	

		// Date start
		print '<tr>';
		print '<td class="fieldrequired">';
		print $form->textwithpicto($langs->trans("DateDebPromo"), $langs->trans("FirstDayOfPromo"));
		print '</td>';
		print '<td>';
		print $form->selectDate(-1, 'date_start_', 0, 0, 0, '', 1, 1);
		print '</td>';
		print '</tr>';

		// Date end
		print '<tr>';
		print '<td class="fieldrequired">';
		print $form->textwithpicto($langs->trans("DateFinCP"), $langs->trans("LastDayOfHoliday"));
		print '</td>';
		print '<td>';
		print $form->selectDate(-1, 'date_end_', 0, 0, 0, '', 1, 1);
		print '</td>';
		print '</tr>';

		// Other attributes
		include DOL_DOCUMENT_ROOT.'/core/tpl/extrafields_add.tpl.php';

		print '</tbody>';
		print '</table>';

		print dol_get_fiche_end();

		print $form->buttonsSaveCancel("CreatePromo");

		print '</from>'."\n";
		if (!empty($conf->use_javascript_ajax)) {
			print "\n".'<script type="text/javascript">';
			print '$(document).ready(function () {
					$("#generate_barcode").click(function() {
						var fk_barcode_type = $("#select_fk_barcode_type").find(":selected").val();
						var type_promo = $("#type").find(":selected").val();
						$.get( "'.dol_buildpath('/marketplus/ajax/get_nextbarcode.php?', 1).'", {
							action: \'getrandompassword\',
							barcode_type: fk_barcode_type,
							type_promo: type_promo
						},
						function(token) {
							$("#barcode").val(token);
						});
					});
			});';
			print '</script>';
		}
	}
} else {
	if ($error) {
		print '<div class="tabBar">';
		print $error;
		print '<br><br><input type="button" value="'.$langs->trans("PromotionCode").'" class="button" onclick="history.go(-1)" />';
		print '</div>';
	} else {
		if ($id > 0) {
			$result = $object->fetch($id);
			$projectstatic->fetch((int)$object->fk_project);
			// check if the user has the right to read this request
			if ($canread && $result) {
				print dol_get_fiche_head($head, 'card', $langs->trans("PromotionCode"), -1, 'promotioncode');
				print $form->showbarcode($object);

				print '<div class="fichecenter">';
				print '<div class="fichehalfleft">';
				print '<div class="underbanner clearboth"></div>';

				print '<table class="border tableforfield centpercent">';
				print '<tbody>';

				// code
				print '<tr>';
				print '<td class="titlefield">'.$langs->trans("PromotionCode").'</td>';
				print '<td>';
				print $object->barcode;
				print '</td></tr>';

				// code
				print '<tr>';
				print '<td class="titlefield">'.$langs->trans("Projet").'</td>';
				print '<td>';
				print $projectstatic->title;
				print '</td></tr>';

				// start
				print '<tr>';
				print '<td class="titlefield">'.$langs->trans("DateDebPromo").'</td>';
				print '<td>';
				print $object->date_start;
				print '</td></tr>';

				// end
				print '<tr>';
				print '<td class="titlefield">'.$langs->trans("DateFinPromo").'</td>';
				print '<td>';
				print $object->date_end;
				print '</td></tr>';

				// type
				print '<tr>';
				print '<td class="titlefield">'.$langs->trans("TypePromo").'</td>';
				print '<td>';
				print $object->getTypeLabel($object->type);
				print '</td></tr>';

				// value
				print '<tr>';
				print '<td class="titlefield">'.$langs->trans("ValuePromo").'</td>';
				print '<td>';
				print $object->promo_value;
				print '</td></tr>';

				print '</tbody>';
				print '</table>'."\n";

				print '</div>';
				print '</div>';

				print '<div class="clearboth"></div>';

				print dol_get_fiche_end();

				if ($candelete) {
					print '<a href="'.$_SERVER["PHP_SELF"].'?id='.$object->id.'&action=delete&token='.newToken().'" class="butActionDelete">'.$langs->trans("DeletePromo").'</a>';
				}


				// Confirmation messages
				if ($action == 'delete') {
					if ($candelete) {
						print $form->formconfirm($_SERVER["PHP_SELF"]."?id=".$object->id, $langs->trans("TitleDeletePromo"), $langs->trans("ConfirmDeletePromo"), "confirm_delete", '', 0, 1);
					}
				}

			}
		}
	}
}
// End of page
llxFooter();

if (is_object($db)) {
	$db->close();
}
?>