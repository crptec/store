<?php
/* 
 * Copyright (C) 2022		CRPTEC      <crptec.fr@gmail.com>
 *
 */
// Load Dolibarr environment

$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"] . "/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME'];
$tmp2 = realpath(__FILE__);
$i = strlen($tmp) - 1;
$j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
	$i--;
	$j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1)) . "/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1)) . "/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1))) . "/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1))) . "/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

global $db, $conf, $user, $langs;

$langs->loadLangs(array("marketplus@marketplus"));

require_once DOL_DOCUMENT_ROOT . '/compta/facture/class/facture.class.php';
require_once '../class/promotion_code.class.php';

$barcode_type = GETPOST('barcode_type', 'int');
$type_promo = GETPOST('type_promo', 'int');
$action = GETPOST('action', 'int'); // 1: auto save in database or 0 

if (empty($user->rights->takepos->run)) {
	accessforbidden();
}

$result = 0;
$error = 0;


if ($type_promo > 0 and $type_promo < 10)
{
	$code_magazin = (getDolGlobalString('TAKEPOS_FIDELITY_CODE_MAGAZIN')) ? getDolGlobalString('TAKEPOS_FIDELITY_CODE_MAGAZIN') : "000" ;
	$promotion_value = (getDolGlobalString('TAKEPOS_FIDELITY_DEFAULT_VALUE')) ? getDolGlobalString('TAKEPOS_FIDELITY_DEFAULT_VALUE') : 10 ;
	$enddate_validation = (getDolGlobalString('TAKEPOS_FIDELITY_DEFAULT_ENDATE')) ? getDolGlobalString('TAKEPOS_FIDELITY_DEFAULT_ENDATE') : '31/12/3000' ;
	$v_year=(int) substr($enddate_validation, 6, 4);
	$v_month=(int) substr($enddate_validation, 3, 2);
	$v_day=(int) substr($enddate_validation, 0, 2);

	$mincode = (int)(((int) $type_promo).$code_magazin.'00000001');
	$generated_code = $mincode; //default
	$sql = "SELECT max(barcode) as barcode FROM ". MAIN_DB_PREFIX . "promotion_code pm WHERE pm.type=".$type_promo;
	$resql = $db->query($sql);
	if ($resql) {
		if ($db->num_rows($resql) > 0) {
			$obj = $db->fetch_object($resql);
			$maxdbcode = (int) $obj->barcode;
			$maxcurrentcode = max($mincode, $maxdbcode);
			$generated_code = $maxcurrentcode+1;
		} else {
			$generated_code = $mincode;
		}
		//if it is fidelity programme, insert to table to memory client
		if ($action && $type_promo == 5) {
			$object = new PromotionCode($db);
			$db->begin();
			$object->barcode_type = GETPOST('fk_barcode_type');
			$object->barcode = $generated_code;
			$object->fk_user_create = 1;
			$object->fk_user_benef = 2;
			$date_start = dol_mktime(0, 0, 0, date("m"), date("d"), date("Y"));
			$date_end = dol_mktime(23, 59, 59, $v_month, $v_day, $v_year);
			$object->date_start = $date_start;
			$object->date_end = $date_end;
			$object->type = $type_promo;
			$object->promo_value = $promotion_value;
			$object->fk_project = 1;

			$result = $object->create($user);
			if ($result <= 0) {
				error_log("Error 4 ".var_dump($object->errors));
				$error++;
			}
		}
		if (!$error) {
			$db->commit();
			$sendinfo = array();
			$sendinfo['fidelitycode'] = $generated_code;
			$sendinfo['fidelityvalue'] = $promotion_value;
			$sendinfo['fidelityenddate'] = $enddate_validation;
			$limit_lost_promo = (getDolGlobalString('TAKEPOS_FIDELITY_DEFAULT_NBDAYS')) ? getDolGlobalString('TAKEPOS_FIDELITY_DEFAULT_NBDAYS') : 14 ;
			$sendinfo['fidelitynbdays'] = $limit_lost_promo;
			$sendinfo['fidelitystore'] = getDolGlobalString('MAIN_INFO_SOCIETE_NOM');
			echo json_encode($sendinfo);
		} else {
			echo "Error 3";
		}
	} else {
		echo "Error 1";
	}
} else {
	error_log("type: "+$type_promo);
	echo "Error 2";
}
?>