<?php
/* Copyright (C) 2022  XuanTan NGUYEN     <crptec.fr@gmail.com> */

/**
 * Class to manage Receipt Printers
 */
class dolProductsPrinter
{
	/**
	 *
	 * @var string $printerName
	 *  The name of the target printer.
	 */
	private $printerName;
	/**
	 * @var string Error code (or message)
	 */
	public $error = '';

	/**
	 * @var string[] Error codes (or messages)
	 */
	public $errors = array();
	/**
	 * Constructor
	 *
	 * @param   DoliDB      $db         database
	 */
	public function __construct($db)
	{
		$this->db = $db;
	}

	protected function createPrinterCmdFile($filename)
	{
		$filePath = '/var/www/html/cmdprint_'.$filename;
		$content = "#PDF-BANNER\n";
		$content .= "Template /var/www/html/prdprint_".$filename.".pdf";
		$ret = file_put_contents($filePath, $content);
		if ($ret==false) dol_syslog("dolproductsprinter.class.php::Permission denied to write file ".$filePath, LOG_WARNING);
		else dol_syslog("dolproductsprinter.class.php::Created file ".$filePath." with ".$ret." bytes" , LOG_WARNING);

		return $error;
	}

	protected function createInvoiceProductLinePDF($filename, $label, $line, $options)
	{
		$filePath = '/var/www/html/prdprint_'.$filename.'.pdf';
		// Load TCPDF
		require_once TCPDF_PATH.'tcpdf.php';
		dol_syslog("call TCFDF at ".TCPDF_PATH.'tcpdf.php');
		dol_syslog("write to ".$filePath);
		$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
		$pdf->SetFont('dejavusans', '', 40, '', true);
		$pdf->setPrintHeader(false);
		$pdf->setPrintFooter(false);
		$pdf->SetMargins(10, 3, 10);
		$pdf->AddPage();
		$Y = 0;
		$pdf->Cell(0, $Y, $label, 0, 0, 'L', 0, '', 0);
		$Y = $Y + 20;
		$pdf->SetY($Y);
		$pdf->Cell(0, $Y, strip_tags(htmlspecialchars_decode($line->product_label)), 0, 0, 'L');
		$nboptions = count($options);
		$pdf->SetFont('dejavusans', '', 30, '', true);
		for ($optionline = 0; $optionline < $nboptions; $optionline++)
		{
			$Y = $Y + 15;
			$pdf->SetY($Y);
			$pdf->Cell(0, 0, $options[$optionline]->qty."    ".strip_tags(htmlspecialchars_decode($options[$optionline]->product_label)), 0, 0 , 'R', 0, '', 0);
		}
		$pdf->lastPage();
		$pdf->Output($filePath, 'F');

		return $error;
	}

	/**
	 *  Function to Print Receipt Ticket
	 *
	 *  @param   Facture|Commande   $object         Order or invoice object
	 *  @param   int       			$printerid      Printer id
	 *  @return  int                				0 if OK; >0 if KO
	 */
	public function sendToPrinter($object, $printername)
	{
		global $conf, $mysoc, $langs, $user;
		$error = 0;

		$ret = $this->initPrinter($printername);
		if ($ret > 0) {
			setEventMessages($this->error, $this->errors, 'errors');
		} else {
			$nbproductline = 0;
			$bipeur="";
			$items = array();
			foreach ($object->lines as $line) {
				if (substr($line->description, 0, 15) == "Service: BIPEUR") {
					$bipeur=substr($line->description,17,20);
				}
				if (!empty($line->fk_product) && empty($line->fk_parent_line)) {
					$nbproductline++;
				}
			}
			$i=1;
			foreach ($object->lines as $line) {
				//product
				if (!empty($line->fk_product) && empty($line->fk_parent_line)) {
					$item = array();

					$label = $object->ref."(P_".$i."/".$nbproductline.") E:".$bipeur;
					$item['ticket_label'] = $label;
					$item['product_label'] = $line->product_label;
					$item['product_qty'] = $line->qty;

					$filename = $object->ref."_".$i;
					$item['filename'] = $filename;

					if ($conf->global->TAKEPOS_PRINT_METHOD != "takeposconnector") {
						$error = $this->createPrinterCmdFile($filename);
					}

					$options = array();
					$adds = array();
					foreach ($object->lines as $option) {
						//addition product
						if (!empty($option->fk_product) && !empty($option->fk_parent_line) && ($line->rowid == $option->fk_parent_line)) {
							$options[] = $option;
							$add = array();
							$add['add_qty'] = $option->qty;
							$add['add_label'] = $option->product_label;
							$adds[] = $add;
						}
					}
					$item['adds'] = $adds;

					if ($conf->global->TAKEPOS_PRINT_METHOD != "takeposconnector") {
						$error = $this->createInvoiceProductLinePDF($filename, $label, $line, $options);
						$fileCmdPath = '/var/www/html/cmdprint_'.$filename;
						$cmd = sprintf(
							"lp -n ".$item['product_qty']." -d %s %s",
							$printername,
							$fileCmdPath
						);
						try {
							$this->getCmdOutput($cmd);
						} catch (Exception $e) {
							unlink($fileCmdPath);
							throw $e;
						}
						unlink($fileCmdPath);
					}
					$items[] = $item;
					$i++;
				}
			}
			if ($conf->global->TAKEPOS_PRINT_METHOD == "takeposconnector") {
				$data = json_encode($items);
				dol_syslog($data);
				return $data;
			}
		}
		return $error;
	}

/**
	 *  Function Init Printer
	 *
	 *  @param   int       $printerid       Printer id
	 *  @return  int                        0 if OK; >0 if KO
	 */
	public function initPrinter($printername)
	{
		global $conf;

		$error = 0;
		if ($conf->global->TAKEPOS_PRINT_METHOD != "takeposconnector") {
			$sql = 'SELECT rowid, name, fk_type, fk_profile, parameter';
			$sql .= ' FROM '.MAIN_DB_PREFIX.'printer_receipt';
			$sql .= ' WHERE name = "'.$printername.'"';
			$resql = $this->db->query($sql);
			if ($resql) {
				$obj = $this->db->fetch_array($resql);
			} else {
				$error++;
				$this->errors[] = $this->db->lasterror;
			}
			if (empty($obj)) {
				$error++;
				$this->errors[] = 'PrinterDontExist';
			}

			$parameter = $obj['parameter'];
			$valid = $this->getLocalPrinters();
			if (count($valid) == 0) {
				$error++;
				$this->errors[] = 'LocalPrinterDontExist';
			}
			if (array_search($parameter, $valid, true) === false) {
				$error++;
				$this->errors[] = 'PrinterDontMatch';
			}
			if(!$error) {$this->printerName = $parameter;}
		}
		return $error;
	}

	/**
	 * Run a command and throw an exception if it fails, or return the output if it works.
	 * (Basically exec() with good error handling)
	 *
	 * @param string $cmd
	 *          Command to run
	*/
	protected function getCmdOutput($cmd)
	{
		$descriptors = array (
				1 => array (
						"pipe",
						"w"
				),
				2 => array (
						"pipe",
						"w"
				)
		);
		$process = proc_open($cmd, $descriptors, $fd);
		if (! is_resource($process)) {
			throw new Exception("Command '$cmd' failed to start.");
		}
		/* Read stdout */
		$outputStr = stream_get_contents($fd [1]);
		fclose($fd [1]);
		/* Read stderr */
		$errorStr = stream_get_contents($fd [2]);
		fclose($fd [2]);
		/* Finish up */
		$retval = proc_close($process);
		if ($retval != 0) {
			throw new Exception("Command $cmd failed: $errorStr");
		}
		return $outputStr;
	}

	/**
	 * Load a list of CUPS printers.
	 *
	 * @return array A list of printer names installed on this system. Any item
	 *  on this list is valid for constructing a printer.
	 */
	protected function getLocalPrinters()
	{
		$outpStr = $this->getCmdOutput("lpstat -a");
		$outpLines = explode("\n", trim($outpStr));
		foreach ($outpLines as $line) {
			$ret [] = $this->chopLpstatLine($line);
		}
		return $ret;
	}

	/**
	 * Get the item before the first space in a string
	 *
	 * @param string $line
	 * @return string the string, up to the first space, or the whole string if it contains no spaces.
	 */
	private function chopLpstatLine($line)
	{
		if (($pos = strpos($line, " ")) === false) {
			return $line;
		} else {
			return substr($line, 0, $pos);
		}
	}
}
?>