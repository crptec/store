<?php
/* Copyright (C) 2018	Andreu Bisquerra	<jove@bisquerra.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 *	\file       htdocs/takepos/reduction.php
 *	\ingroup	takepos
 *	\brief      Page with the content of the popup to enter reductions
 */

//if (! defined('NOREQUIREUSER'))	define('NOREQUIREUSER', '1');	// Not disabled cause need to load personalized language
//if (! defined('NOREQUIREDB'))		define('NOREQUIREDB', '1');		// Not disabled cause need to load personalized language
//if (! defined('NOREQUIRESOC'))		define('NOREQUIRESOC', '1');
//if (! defined('NOREQUIRETRAN'))		define('NOREQUIRETRAN', '1');
if (!defined('NOCSRFCHECK')) {
	define('NOCSRFCHECK', '1');
}
if (!defined('NOTOKENRENEWAL')) {
	define('NOTOKENRENEWAL', '1');
}
if (!defined('NOREQUIREMENU')) {
	define('NOREQUIREMENU', '1');
}
if (!defined('NOREQUIREHTML')) {
	define('NOREQUIREHTML', '1');
}
if (!defined('NOREQUIREAJAX')) {
	define('NOREQUIREAJAX', '1');
}

require '../main.inc.php'; // Load $user and permissions
require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php';

$place = (GETPOST('place', 'aZ09') ? GETPOST('place', 'aZ09') : 0); // $place is id of table for Ba or Restaurant
$invoiceid = GETPOST('invoiceid', 'int');
$selectedline = GETPOST('selectedline', 'int');

if (empty($user->rights->takepos->run)) {
	accessforbidden();
}


/*
 * View
 */

$invoice = new Facture($db);
if ($invoiceid > 0) {
	$invoice->fetch($invoiceid);
} else {
	$sql = "SELECT rowid FROM ".MAIN_DB_PREFIX."facture where ref='(PROV-POS".$_SESSION["takeposterminal"]."-".$place.")'";
	$resql = $db->query($sql);
	$obj = $db->fetch_object($resql);
	if ($obj) {
		$invoiceid = $obj->rowid;
	}
	if (!$invoiceid) {
		$invoiceid = 0; // Invoice does not exist yet
	} else {
		$invoice->fetch($invoiceid);
	}
}

$selectedlinetva = 0;
$selectedlinetotal = 0;
if ($selectedline > 0 && $invoiceid > 0) { // invoiceid exist because we are selected in 1 line
	$sql = "SELECT rowid, tva_tx, total_ttc FROM ".MAIN_DB_PREFIX."facturedet where fk_facture = ".((int) $invoiceid)." AND rowid=".$selectedline;
	$resql = $db->query($sql);
	$num = $db->num_rows($resql);
	if ($num) {
		$invoiceline = $db->fetch_array($resql);
		$selectedlinetva = price2num($invoiceline['tva_tx']);
		$selectedlinetotal = price2num($invoiceline['total_ttc']);
	}
}

$arrayofcss = array('/takepos/css/pos.css.php');
$arrayofjs  = array();

top_htmlhead($head, '', 0, 0, $arrayofjs, $arrayofcss);

$langs->loadLangs(array('main', 'bills', 'cashdesk'));

if (!isset($conf->global->TAKEPOS_NUMPAD_USE_PAYMENT_ICON) || !empty($conf->global->TAKEPOS_NUMPAD_USE_PAYMENT_ICON)) {
	$htmlReductionPercent = '<span class="fa fa-2x fa-percent"></span>';
	$htmlReductionAmount = '<span class="fa fa-2x fa-money"></span><br>'.$langs->trans('Amount');
} else {
	$htmlReductionPercent = $langs->trans('ReductionShort').'<br>%';
	$htmlReductionAmount = $langs->trans('ReductionShort').'<br>'.$langs->trans('Amount');
}
?>
<link rel="stylesheet" href="css/pos.css.php">
</head>
<body>

<script>
	var reductionType ='';
	var reductionTotal = '';
	var editAction = '';
	var editNumber = '';
	var htmlBtnOK = '<span style="font-size: 14pt;">OK</span>';
	var htmlReductionPercent = '<?php echo dol_escape_js($htmlReductionPercent); ?>';
	var htmlReductionAmount = '<?php echo dol_escape_js($htmlReductionAmount); ?>';
	var search_timer=null;

	/**
	 * Reset values
	 */
	function Reset()
	{
		reductionType = '';
		reductionTotal = '';
		editAction = '';
		editNumber = '';
		jQuery('#reduction_total').val(reductionTotal);
		jQuery("#reduction_type_percent").html(htmlReductionPercent);
		jQuery('#reduction_type_amount').html(htmlReductionAmount);
	}

	/**
	 * Edit action
	 *
	 * @param   {string}  number    Number pressed
	 */
	function Edit(number)
	{
		console.log('Edit ' + number);

		if (number === 'p') {
			if (editAction === 'p' && reductionType === 'percent'){
				ValidateReduction();
			} else {
				editAction = 'p';
			}
			reductionType = 'percent';
		} else if (number === 'a') {
			if (editAction === 'a' && reductionType === 'amount'){
				ValidateReduction();
			} else {
				editAction = 'a';
			}
			reductionType = 'amount';
		}

		if (editAction === 'p'){
			jQuery('#reduction_type_percent').html(htmlBtnOK);
			jQuery('#reduction_type_amount').html(htmlReductionAmount);
		} else if (editAction === 'a'){
			jQuery('#reduction_type_amount').html(htmlBtnOK);
			jQuery("#reduction_type_percent").html(htmlReductionPercent);
		} else {
			jQuery('#reduction_type_percent').html(htmlReductionPercent);
			jQuery('#reduction_type_amount').html(htmlReductionAmount);
		}
	}

	/**
	 * Add a number in reduction input
	 *
	 * @param   {string}    reductionNumber     Number pressed
	 */
	function AddReduction(reductionNumber)
	{
		console.log('AddReduction ' + reductionNumber);

		reductionTotal += String(reductionNumber);
		jQuery('#reduction_total').val(reductionTotal);
	}

	/**
	 * Validate a reduction
	 */
	function ValidateReduction()
	{
		console.log('ValidateReduction');

		if (reductionTotal.length <= 0) {
			console.error('Error no reduction');
			$("#errormessage").text("Error no reduction");
			return;
		}

		var reductionNumber = parseFloat(reductionTotal);
		if (isNaN(reductionNumber)) {
			console.error('Error not a valid number :', reductionNumber);
			$("#errormessage").text("Error not a valid number "+reductionNumber);
			return;
		}

		if (reductionType === 'percent') {
			var invoiceid = <?php echo ($invoiceid > 0 ? $invoiceid : 0); ?>;
			parent.$("#poslines").load("invoice.php?action=update_reduction_global&place=<?php echo $place; ?>&number="+reductionNumber+"&invoiceid="+invoiceid, function() {
				Reset();
				parent.$.colorbox.close();
			});
		} else if (reductionType === 'amount') {
			var desc = "<?php echo dol_escape_js($langs->transnoentities('Reduction')); ?>";
			parent.$("#poslines").load("invoice.php?action=freezone&place=<?php echo $place; ?>&number=-"+reductionNumber+"&desc="+desc, function() {
				Reset();
				parent.$.colorbox.close();
			});
		} else {
			console.error('Error bad reduction type :', reductionType);
			$("#errormessage").text("Error not a valid number "+reductionType);
		}
	}

<?php
if (!empty($conf->global->TAKEPOS_REDUCTION_BARCODE)) {
?>
	/**
	 * Apply reduction with barcode type 1 (amount) or 2(percent)
	 */
	function ApplyReductionBarcode(typepromo, valuepromo, codepromo)
	{
		var desc = "Code:"+codepromo;
		var reductionNumber = 0;
		var vselectedline = parseFloat($("#selectedline").text());
		var vselectedlinetva = parseFloat($("#selectedlinetva").text());
		var vselectedlinetotal = parseFloat($("#selectedlinetotal").text());

		console.log(typepromo + ": application promo " + valuepromo + " for total " + totalinvoice);
		if (typepromo == 1) {
			reductionNumber = valuepromo;
		} else if (typepromo == 2) {
			var totalinvoice = parseFloat($("#total").text());
			if (isNaN(totalinvoice)) {
				console.log("cannot read invoice total. promotion is set to 0");
				reductionNumber =0;
			} else {
				console.log("application promo " + valuepromo + " for total " + totalinvoice);
				reductionNumber = Math.round(totalinvoice * valuepromo) / 100;
			}
		} else if (typepromo == 3 || typepromo == 4) {
			if (isNaN(vselectedline) || isNaN(vselectedlinetva) || isNaN(vselectedlinetotal)) {
				console.log("cannot read invoice line info. promotion is set to 0");
				reductionNumber = 0;
			} else {
				reductionNumber = valuepromo;
				if (typepromo == 4) {
					reductionNumber = Math.round(vselectedlinetotal * valuepromo) / 100;
				}
			}
		} else {
			reductionNumber = 0;
		}
		//apply reduction
		if (reductionNumber > 0 && (typepromo == 1 || typepromo == 2)) {
			parent.$("#poslines").load("invoice.php?action=freezone&place=<?php echo $place; ?>&number=-"+reductionNumber+"&desc="+desc, function() {
					Reset();
					parent.$.colorbox.close();
			});
		}

		if (reductionNumber > 0 && (typepromo == 3 || typepromo == 4)) {
			parent.$("#poslines").load("invoice.php?action=freezone&place=<?php echo $place; ?>&number=-"+reductionNumber+"&desc="+desc+"&tva_tx="+vselectedlinetva, function() {
					Reset();
					parent.$.colorbox.close();
			});
		}
	}

	function SearchPromo(keyCodeForEnter)
	{
		var search = false;
		var eventKeyCode = window.event.keyCode;
		if (typeof keyCodeForEnter === 'undefined' || eventKeyCode == keyCodeForEnter) {
			search = true;
		}

		if (search === true) {
			// temporization time to give time to type
			if (search_timer) {
				clearTimeout(search_timer);
			}

			search_timer = setTimeout(function(){
				var reductionTotal = $("#reduction_total").val();
				var post = undefined;
				var invoiceid = 1;
				post = $.post("<?php echo dol_buildpath("/marketplus/ajax/load_promotion.php", 1); ?>", {promotioncode: reductionTotal, object: invoiceid}, function(data){
					console.log(data);
					const dataSplitArray = data.split(';');
					var typepromo = parseInt(dataSplitArray[0]);
					var valuepromo = parseFloat(dataSplitArray[1]);
					var codepromo = parseInt(dataSplitArray[2]);
					if (isNaN(typepromo)) {
						console.error('Error invalid typepromo');
						console.log(dataSplitArray);
						$('#discount').val('<?php
							$langs->load('marketplus@marketplus');
							echo dol_escape_js($langs->trans("ErrorInternal"));
						?>');
					} else {
						if (typepromo < 0) {
							$("#discount").html('<?php
								$langs->loadLangs(array("marketplus@marketplus", "error"));
								echo $langs->trans("ErrorReturnCode");
							?>' + typepromo);
						} else if (typepromo == 0) {
							$('#discount').html('<?php
								$langs->load('marketplus@marketplus');
								echo dol_escape_js($langs->trans("ErrorPromoExpired"));
							?>');
						} else {
							if (typepromo == 1 || typepromo == 2 || typepromo == 3 || typepromo == 4) {
								if (!isNaN(valuepromo)) {
									ApplyReductionBarcode(typepromo, valuepromo, codepromo);
								} else {
									console.error('Error invalid valuepromo');
									console.log(dataSplitArray);
									$('#discount').html('<?php
										$langs->load('marketplus@marketplus');
										echo dol_escape_js($langs->trans("ErrorInternal"));
									?>');
								}
							}
						}
					}
				});
			}, 500); // 500ms delay
		}
	}

<?php
}
?>
</script>

<div style="position:absolute; top:2%; left:5%; width:91%;">
<center>
<?php
if (!empty($conf->global->TAKEPOS_REDUCTION_BARCODE)) {
	$keyCodeForEnter = getDolGlobalInt('CASHDESK_READER_KEYCODE_FOR_ENTER'.$_SESSION['takeposterminal']) > 0 ? getDolGlobalInt('CASHDESK_READER_KEYCODE_FOR_ENTER'.$_SESSION['takeposterminal']) : '';
	print '<input type="text" class="takepospay" id="reduction_total" name="reduction_total" style="width: 50%;" onkeyup="SearchPromo('.$keyCodeForEnter.')" placeholder="'.$langs->trans('Reduction').'">';
}
?>
</center>
</div>

<?php
if (!empty($conf->global->TAKEPOS_REDUCTION_BARCODE)) {
	$langs->load('marketplus@marketplus');
	print '<div style="position:absolute; top:12%; left:5%; width:91%;">';
	print '<b>'.$langs->trans('Bill').'</b>: <span id="ref" name="ref">'.$invoice->ref.'</span><br>';
	print '<b>'.$langs->trans('TotalToPay').'</b>: <span id="total" name="total">'.price2num($invoice->total_ttc).'</span> '.$conf->currency.'<br>';
	print '<b>'.$langs->trans('Line').'</b>: <span id="selectedline" name="selectedline">'.$selectedline.'</span><br>';
	print '<b>'.$langs->trans('LineTVA').'</b>: <span id="selectedlinetva" name="selectedlinetva">'.$selectedlinetva.'</span><br>';
	print '<b>'.$langs->trans('LineTotal').'</b>: <span id="selectedlinetotal" name="selectedlinetotal">'.$selectedlinetotal.'</span><br>';
	print '<b>'.$langs->trans('Discounts').'</b>: <span id="discount" name="discount"></span><br>';
	print '<b style="color:red;"><span id="errormessage" name="errormessage"></span></b><br>';
	print '</div>';
}
?>

<div style="position:absolute; top:33%; left:5%; height:52%; width:92%;">
<?php
if (empty($conf->global->TAKEPOS_REDUCTION_LIMIT_INPUT)) {
	print '<button type="button" class="calcbutton" onclick="AddReduction(7);">7</button>';
	print '<button type="button" class="calcbutton" onclick="AddReduction(8);">8</button>';
	print '<button type="button" class="calcbutton" onclick="AddReduction(9);">9</button>';
	print '<button type="button" class="calcbutton2" id="reduction_type_percent" onclick="Edit(\'p\');">'.$htmlReductionPercent.'</button>';
	print '<button type="button" class="calcbutton" onclick="AddReduction(4);">4</button>';
	print '<button type="button" class="calcbutton" onclick="AddReduction(5);">5</button>';
	print '<button type="button" class="calcbutton" onclick="AddReduction(6);">6</button>';
	print '<button type="button" class="calcbutton2" id="reduction_type_amount" onclick="Edit(\'a\');">'.$htmlReductionAmount.'</button>';
	print '<button type="button" class="calcbutton" onclick="AddReduction(1);">1</button>';
	print '<button type="button" class="calcbutton" onclick="AddReduction(2);">2</button>';
	print '<button type="button" class="calcbutton" onclick="AddReduction(3);">3</button>';
	print '<button type="button" class="calcbutton3 poscolorblue" onclick="Reset();"><span id="printtext" style="font-weight: bold; font-size: 18pt;">C</span></button>';
	print '<button type="button" class="calcbutton" onclick="AddReduction(0);">0</button>';
	print '<button type="button" class="calcbutton" onclick="AddReduction(\'.\');">.</button>';
	print '<button type="button" class="calcbutton">&nbsp;</button>';
	print '<button type="button" class="calcbutton3 poscolordelete" onclick="parent.$.colorbox.close();"><span id="printtext" style="font-weight: bold; font-size: 18pt;">X</span></button>';
} else {
	print '<input type="button" class="button takepospay clearboth" value="PROMO: 10%" onclick="ApplyReductionBarcode(2, 10, \'PMM10\');">';
	print '<input type="button" class="button takepospay clearboth" value="PROMO: 20%" onclick="ApplyReductionBarcode(2, 20, \'PMM20\');">';
	print '<input type="button" class="button takepospay clearboth" value="PROMO: 30%" onclick="ApplyReductionBarcode(2, 30, \'PMM30\');"><br><br>';
	print '<input type="button" class="button takepospay clearboth" value="PROMO: 1€" onclick="ApplyReductionBarcode(1, 1, \'PMA1\');">';
	print '<input type="button" class="button takepospay clearboth" value="PROMO: 2€" onclick="ApplyReductionBarcode(1, 2, \'PMA2\');">';
	print '<input type="button" class="button takepospay clearboth" value="PROMO: 3€" onclick="ApplyReductionBarcode(1, 3, \'PMA3\');"><br><br>';
	print '<input type="button" class="button takepospay clearboth" value="EMP: 100%" onclick="ApplyReductionBarcode(2, 100, \'EMP100\');"><br><br>';
	print '<input type="button" class="button takepospay clearboth" value="PARTNER: 30%" onclick="ApplyReductionBarcode(2, 30, \'PMP30\');">';
	print '<input type="button" class="button takepospay clearboth" value="PARTNER: 100%" onclick="ApplyReductionBarcode(2, 100, \'PMP100\');"><br>';

}
?>
</div>
<script>
	$("#reduction_total").focus();
</script>

</body>
</html>
