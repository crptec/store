<?php
/* 
 * Copyright (C) 2022		CRPTEC      <crptec.fr@gmail.com>
 *
 */
// Load Dolibarr environment

$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"] . "/main.inc.php";
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME'];
$tmp2 = realpath(__FILE__);
$i = strlen($tmp) - 1;
$j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
	$i--;
	$j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1)) . "/main.inc.php")) $res = @include substr($tmp, 0, ($i + 1)) . "/main.inc.php";
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1))) . "/main.inc.php")) $res = @include dirname(substr($tmp, 0, ($i + 1))) . "/main.inc.php";
// Try main.inc.php using relative path
if (!$res && file_exists("../main.inc.php")) $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

/*at this step, main.inc.php is loaded with $user and permissions*/

global $db, $conf, $user, $langs;

$langs->loadLangs(array("marketplus@marketplus"));

require_once DOL_DOCUMENT_ROOT . '/compta/facture/class/facture.class.php';

$invoiceid = GETPOST('object', 'int');
$promotioncode = GETPOST('promotioncode', 'alpha');

$now = dol_now();

function checkPromotionCode($promotioncode)
{
	if (strlen($promotioncode) != 13 && strlen($promotioncode) != 12) return -1;
	if (!preg_match("/^[0-9]*$/", $promotioncode)) return -1;
	return 1;
}

function status($user, $db, $conf, $object, $langs, $promotioncode)
{
	$db->begin();
	$sql =  "SELECT pm.rowid, pm.ref_ext, pm.entity, pm.barcode, pm.fk_barcode_type, pm.fk_user_create,";
	$sql .= " pm.active, pm.date_start, pm.date_end, pm.type, pm.promo_value ";
	$sql .= " FROM " . MAIN_DB_PREFIX . "promotion_code pm";
	$sql .= " WHERE pm.barcode = '".$db->escape(substr($promotioncode, 0, 12))."'";
	$sql .= " AND pm.date_start <= NOW()";
	$sql .= " AND pm.date_end >= NOW()";
	$resql = $db->query($sql);
	if ($resql) {
		if ($db->num_rows($resql) > 0) {
			$obj = $db->fetch_object($resql);
			$typepromo = $obj->type;
			$valuepromo = $obj->promo_value;
			$codepromo = $obj->barcode;

			//we are in fidelity case.
			if ($obj->type == 5) {
				//we find the last facture in 14 days which has this fidelity code
				$sql = "SELECT total_ttc FROM ".MAIN_DB_PREFIX."facture f WHERE note_public='".$db->escape(substr($promotioncode, 0, 12))."'";
				$sql .= " AND f.datef >= date_sub(CURDATE(), INTERVAL 14 DAY) AND paye=1";
				$sql .= " ORDER BY f.datef";
				$sql .= " LIMIT 1";
				$resql_f = $db->query($sql);
				if ($resql_f && ($db->num_rows($sql) > 0)) {
					$last_f = $db->fetch_object($resql_f);
					if ($last_f) {
						$valuepromo = price(($valuepromo * $last_f->total_ttc) / 100);
					}
				}
				//nothing found -> no promo
				else {
					$valuepromo = 0;
				}
			}

			$message = $typepromo.";".$valuepromo.";".$codepromo;
			echo $message;
		} else {
			echo "0";
		}
	} else {
		echo "-1";
	}
}

if (!empty($promotioncode))
{
	if (checkPromotionCode($promotioncode) == -1) {
		echo "-3";
		exit;
	}
	$object = array();
	if (!empty($invoiceid) && $invoiceid > 0) {
		$object = new Facture($db);
		$object->fetch($invoiceid);
	}
	status($user, $db, $conf, $object, $langs, $promotioncode);
}
else
{
	echo "-2";
}
?>