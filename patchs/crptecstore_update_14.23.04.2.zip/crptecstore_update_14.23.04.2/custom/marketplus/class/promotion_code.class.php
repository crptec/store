<?php
/* 
 * Copyright (C) 2022    CRPTEC<crptec.fr@gmail.com>
 */

require_once DOL_DOCUMENT_ROOT.'/core/class/commonobject.class.php';

/**
 *	Class of the module MarketPlus. Developed by CRPTEC ( https://www.crptec.com/ )
 */
class PromotionCode extends CommonObject
{
	/**
	 * @var string ID to identify managed object
	 */
	public $element = 'promotioncode';
	/**
	 * @var string Name of table without prefix where object is stored
	 */
	public $table_element = 'promotion_code';
	/**
	 * 0=No test on entity, 1=Test with field entity, 2=Test with link by societe
	 * @var int
	 */
	public $ismultientitymanaged = 0;
	/**
	 * @var string String with name of icon for myobject. Must be the part after the 'object_' into object_myobject.png
	 */
	public $picto = 'promotion';
	/**
	 * @var int Object Id
	 */
	public $id;
	/**
	 * @var int UniqueCode promotion
	 */
	public $barcode;
	/**
	 * @var int UniqueCode promotion
	 */
	public $barcode_type;
	/**
	 * @var int User ID of creator
	 */
	public $fk_user_create;
	/**
	 * @var int User ID of benefitor
	 */
	public $fk_user_benef;
	/**
	 * @var string description
	 */
	public $description;

	public $date_start = ''; // Date start in PHP server TZ
	public $date_end = ''; // Date end in PHP server TZ
	/**
	 * @var int active
	 * 0: one time code, 1: periode, 2: permanant
	 */
	public $active;
	/**
	 * @var int type
	 * 1: amount, 2: percent, 3: product rowid, 4: fidelity program
	 */
	public $type;
	/**
	 * @var int $promo_value
	 * dependence of type
	 */
	public $promo_value;
	/**
	 * @var int fk_project
	 * dependence of type
	 */
	public $fk_project;

	/**
	 *   Constructor
	 *
	 *   @param		DoliDB		$db      Database handler
	 */
	public function __construct($db)
	{
		$this->db = $db;
	}

	/**
	 *   create a new promotion code in database
	 *
	 *   @param		User	$user        	User that create
	 *   @param     int		$notrigger	    0=launch triggers after, 1=disable triggers
	 *   @return    int			         	<0 if KO, Id of created object if OK
	 */
	public function create($user, $notrigger = 0)
	{
		global $conf;
		$error = 0;

		$now = dol_now();

		// Check parameters
		if (empty($this->fk_user_create) || !is_numeric($this->fk_user_create) || $this->fk_user_create < 0) {
			$this->error = "ErrorBadParameterFkUser"; return -1;
		}
		if (empty($this->type) || !is_numeric($this->type) || $this->type <= 0) {
			$this->error = "ErrorBadParameterFkType"; return -1;
		}

		// Insert request
		$sql = "INSERT INTO ".MAIN_DB_PREFIX."promotion_code(";
		$sql .= "entity,";
		$sql .= "barcode,";
		$sql .= "fk_barcode_type,";
		$sql .= "fk_user_create,";
		$sql .= "fk_user_benef,";
		$sql .= "active,";
		$sql .= "date_start,";
		$sql .= "date_end,";
		$sql .= "type,";
		$sql .= "promo_value,";
		$sql .= "fk_project";
		$sql .= ") VALUES (";
		$sql .= "1,";
		$sql .= " ".(empty($this->barcode) ? "null" : "'".$this->db->escape($this->barcode)."'").",";
		$sql .= " ".(empty($this->barcode_type) ? "null" : $this->db->escape($this->barcode_type)).",";
		$sql .= " ".((int) $this->fk_user_create).",";
		$sql .= ' '.(empty($this->fk_user_benef)?'1': ((int) $this->fk_user_benef)).', ';
		$sql .= ' '.(empty($this->active)?'1': ((int)$this->active)).', ';
		$sql .= ' '.(empty($this->date_start)? 'NOW()':"'".$this->db->idate($this->date_start)."'").', ';
		$sql .= ' '.(empty($this->date_end)? 'NOW()+ internval 7 day':"'".$this->db->idate($this->date_end)."'").', ';
		$sql .= ' '.(empty($this->type)?'0': ((int) $this->type)).', ';
		$sql .= ' '.(empty($this->promo_value)?'0': ((float) $this->promo_value)).', ';
		$sql .= ' '.(empty($this->fk_project)?'0': ((int) $this->fk_project));
		$sql .= ")";

		$this->db->begin();

		dol_syslog(get_class($this)."::create", LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++; $this->errors[] = "Error ".$this->db->lasterror();
		}

		if (!$error) {
			$this->id = $this->db->last_insert_id(MAIN_DB_PREFIX."promotion_code");
		}
		// Commit or rollback
		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this)."::create ".$errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', '.$errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		} else {
			$this->db->commit();
			return $this->id;
		}
	}
	/**
	 *	Load object in memory from database
	 *
	 *  @param	int		$id         Id object
	 *  @param	string	$ref        Ref object
	 *  @return int         		<0 if KO, 0 if not found, >0 if OK
	 */
	public function fetch($id='', $ref_ext = '', $barcode = '')
	{
		global $langs, $conf;

		dol_syslog(get_class($this)."::fetch id=".$id." ref=".$ref." ref_ext=".$ref_ext);
		// Check parameters
		if (!$id && !$ref_ext && !$barcode) {
			$this->error = 'ErrorWrongParameters';
			dol_syslog(get_class($this)."::fetch ".$this->error, LOG_ERR);
			return -1;
		}

		$sql =  "SELECT pm.rowid, pm.ref_ext, pm.entity, pm.barcode, pm.fk_barcode_type, pm.fk_user_create,";
		$sql .= " pm.active, pm.date_start, pm.date_end, pm.type, pm.promo_value, pm.fk_project";
		$sql .= " FROM " . MAIN_DB_PREFIX . "promotion_code pm";

		if ($id) {
			$sql .= " WHERE pm.rowid = ".((int) $id);
		} else {
			$sql .= " WHERE pm.entity IN (".getEntity($this->element).")";
			if ($ref_ext) {
				$sql .= " AND pm.ref_ext = '".$this->db->escape($ref_ext)."'";
			} elseif ($barcode) {
				$sql .= " AND pm.barcode = '".$this->db->escape($barcode)."'";
			}
		}

		$resql = $this->db->query($sql);
		if ($resql && $this->db->num_rows($resql)) {
				$obj = $this->db->fetch_object($resql);
				
				$this->id = $obj->rowid;
				$this->ref_ext = $obj->ref_ext;
				$this->entity = $obj->entity;
				$this->barcode = $obj->barcode;
				$this->fk_barcode_type = $obj->fk_barcode_type;
				$this->barcode_type = $obj->fk_barcode_type;
				$this->fk_user_create = $obj->fk_user_create;
				$this->active = $obj->active;
				$this->date_start = $obj->date_start;
				$this->date_end = $obj->date_end;
				$this->type = $obj->type;
				$this->promo_value = $obj->promo_value;
				$this->fk_project = $obj->fk_project;

				$this->db->free($resql);
				return 1;
		} else {
			$this->error = $this->db->lasterror();
			return -1;
		}
	}

	/**
	 *	Load object in memory from database
	 *
	 * 1: amount, 2: percent, 3: product rowid, 4: fidelity program
	 */
	public function getTypeLabel($typepromo=0)
	{
		global $langs, $conf;
		$langs->loadLangs(array("marketplus@marketplus"));
		$label = '';
		if ($typepromo == 1) $label = $langs->trans("TypePromoAmount");
		if ($typepromo == 2) $label = $langs->trans("TypePromoPercent");
		if ($typepromo == 3) $label = $langs->trans("TypePromoLineAmount");
		if ($typepromo == 4) $label = $langs->trans("TypePromoLinePercent");
		if ($typepromo == 5) $label = $langs->trans("TypePromoFidelityDirect");
		return $label;
	}

	/**
	 *	Return clicable name (with picto eventually)
	 *
	 *	@param	int			$withpicto					0=_No picto, 1=Includes the picto in the linkn, 2=Picto only
	 *  @param  int     	$save_lastsearch_value    	-1=Auto, 0=No save of lastsearch_values when clicking, 1=Save lastsearch_values whenclicking
	 *  @param  int         $notooltip					1=Disable tooltip
	 *	@return	string									String with URL
	 */
	public function getNomUrl($withpicto = 0, $id = 0, $notooltip = 0)
	{
		global $langs;

		$result = '';
		if ($id == 0) {
			if (isset($this->id)) {
				$id = $this->id;
			} else if (isset($this->rowid)) {
				$id = $this->rowid;
			}
		}
		$label = ' '.$this->barcode;
		$linkclose = '';
		if ($id) {
			$lien = '<a href = "'.dol_buildpath('/marketplus/codepromo_card.php?', 1).'id='.$id.'&action=view"'.$linkclose.'>';
		} else {
			$lien = '';
		}
		$lienfin = empty($lien)?'':'</a>';
		$picto = 'generic';
		if ($withpicto == 1) {
			$result .= $lien.img_object($label, $picto).$label.$lienfin;
		} else {
			$result .= $lien.$label.$lienfin;
		}
		return $result;
	}

	/**
	 *  Return array with list of types
	 *
	 *  @return     array	    		Return array with list of types
	 */
	public function getTypes()
	{
		global $langs;
		
		$langs->loadLangs(array("marketplus@marketplus"));
		$types[1] = array('rowid'=> 1, 'code'=> 'TypePromoAmount', 'label'=> $langs->trans("TypePromoAmount"));
		$types[2] = array('rowid'=> 2, 'code'=> 'TypePromoPercent', 'label'=> $langs->trans("TypePromoPercent"));
		$types[3] = array('rowid'=> 3, 'code'=> 'TypePromoLineAmount', 'label'=> $langs->trans("TypePromoLineAmount"));
		$types[4] = array('rowid'=> 4, 'code'=> 'TypePromoLinePercent', 'label'=> $langs->trans("TypePromoLinePercent"));
		$types[5] = array('rowid'=> 5, 'code'=> 'TypePromoFidelityDirect', 'label'=> $langs->trans("TypePromoFidelityDirect"));
		return $types;
	}

	/**
	 *   Delete object in database
	 *
	 *	 @param		User	$user        	User that delete
	 *   @param     int		$notrigger	    0=launch triggers after, 1=disable triggers
	 *	 @return	int						<0 if KO, >0 if OK
	 */
	public function delete($user, $notrigger = 0)
	{
		global $conf, $langs;
		$error = 0;

		$sql = "DELETE FROM ".MAIN_DB_PREFIX."promotion_code";
		$sql .= " WHERE rowid=".((int) $this->id);

		$this->db->begin();

		dol_syslog(get_class($this)."::delete", LOG_DEBUG);
		$resql = $this->db->query($sql);
		if (!$resql) {
			$error++; $this->errors[] = "Error ".$this->db->lasterror();
		}

		// Commit or rollback
		if ($error) {
			foreach ($this->errors as $errmsg) {
				dol_syslog(get_class($this)."::delete ".$errmsg, LOG_ERR);
				$this->error .= ($this->error ? ', '.$errmsg : $errmsg);
			}
			$this->db->rollback();
			return -1 * $error;
		} else {
			$this->db->commit();
			return 1;
		}
	}
}
?>